---
name: turtle-to-sparql-update
description: Turtle(.ttl) 텍스트를 Knowledge Studio IF-SOR-081의 sparql 입력에 넣을 SPARQL INSERT DATA 문으로 변환한다. T-box·A-box Turtle을 저장소에 추가하기 전, 실제 API 실행과 분리된 변환 단계에서 사용한다.
---

# Turtle을 SPARQL Update로 변환

## 입력과 출력

- 입력: 사용자가 제공한 Turtle 원문 또는 읽을 수 있는 `.ttl` 파일의 전체 내용. 파일을 읽을 수 없거나 일부만 확인됐다면 완전한 원문을 요청한다. 코드 블록에 담겼다면 코드 펜스만 제거한다.
- 출력: `PREFIX`/`BASE` 선언과 `INSERT DATA { ... }`로 구성된 SPARQL Update 원문 하나. 설명문, Markdown 코드 펜스, 저장소 ID, HTTP 요청은 출력하지 않는다.
- 이 스킬은 **변환만** 한다. `knowledge_studio_sparql_update`를 호출하거나 저장소 데이터를 변경하지 않는다. 사용자가 별도로 실행을 요청했을 때만 변환 결과를 그 Workflow의 `sparql` 입력에 전달한다. `repo`는 별도 입력이다.

## 변환 절차

1. Turtle의 맨 앞에 모여 있는 `@prefix 접두어: <IRI> .`를 같은 순서의 `PREFIX 접두어: <IRI>`로, `@base <IRI> .`를 `BASE <IRI>`로 옮긴다. 선언의 마지막 마침표는 SPARQL 선언에 넣지 않는다. 이미 `PREFIX` 또는 `BASE` 형식이면 그대로 둔다.
2. 선언을 제외한 트리플 본문을 `INSERT DATA {`와 `}` 사이에 둔다. 주어·술어·목적어, `a`, `;`, `,`, 언어 태그, 데이터타입, 문자열의 줄바꿈·이스케이프를 임의로 바꾸지 않는다. Turtle 본문 안에 있는 `.`도 보존한다.
3. 주어진 TTL의 모든 내용이 결과에 들어갔는지 대조한다. 접두어가 모두 정의되어 있고 본문이 비어 있지 않은지 확인한다. `INSERT DATA` 안에 조회 변수(`?x`, `$x`)를 새로 만들지 않는다.
4. 최종 응답은 SPARQL Update 원문만 낸다. 문법 검증 도구를 실제로 실행하지 않았다면 “검증 완료”라고 주장하지 않는다.

## 안전한 변환 경계

- 이 절차는 **선언이 상단에 모인 일반 Turtle**에 적용한다. 선언이 트리플 사이에 등장하거나 같은 접두어/BASE가 중간에 재정의되어 앞뒤 의미가 달라지는 경우에는 단순히 선언을 위로 옮기지 않는다. 해당 경우 RDF 파서 기반 변환 도구가 없으면 오류를 설명하고 중단한다.
- 상대 IRI에 필요한 BASE가 원문에 없고 문서 기준 IRI도 제공되지 않았다면 기준 IRI를 추측하지 않는다. 문서 위치에 따라 의미가 달라질 수 있으므로 기준 IRI를 요청한다.
- 빈 노드(`_:id`, `[]`)가 있으면 **한 번의** `INSERT DATA` 요청 안에서 그 연결을 유지한다. 여러 요청으로 임의 분할하지 않는다. SPARQL Update의 빈 노드는 실행 때 새 노드가 되므로, 같은 문장을 재실행하면 기존 빈 노드에 이어 붙는다고 가정하지 않는다.
- 입력이 너무 길어 전체를 확인·출력할 수 없다면 일부만 출력하거나 생략 기호를 넣지 않는다. RDF 파서가 있는 변환 Workflow/코드 도구를 사용하도록 안내한다.
- 이 스킬은 적재용 `INSERT DATA`만 만든다. `DELETE`, `CLEAR`, `DROP`, `LOAD`, `CREATE`를 덧붙이지 않는다. 기존 데이터 제거 또는 교체는 별도 요청과 절차가 필요하다.
- Turtle은 기본 그래프 데이터로 취급한다. 사용자가 명시적으로 대상 그래프 IRI를 준 경우에만 `INSERT DATA { GRAPH <그래프 IRI> { ... } }` 형태를 사용한다. 그래프를 추측하지 않는다.

## 예시

입력 Turtle:

```turtle
@prefix ex: <https://example.org/> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .

ex:Machine rdfs:label "설비"@ko .
```

출력 SPARQL Update:

```sparql
PREFIX ex: <https://example.org/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

INSERT DATA {
  ex:Machine rdfs:label "설비"@ko .
}
```
