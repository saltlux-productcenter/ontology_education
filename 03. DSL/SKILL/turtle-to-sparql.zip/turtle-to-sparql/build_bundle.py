"""Package this Agent Studio skill as an importable Tool DSL."""

import base64
import hashlib
import io
from pathlib import Path
import zipfile

import yaml


SOURCE_ID = "23b177fb-010c-4bd1-846f-706a3d72414a"
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "turtle-to-sparql-update.yaml"


def main() -> None:
    skill_md = (ROOT / "SKILL.md").read_bytes()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        member = zipfile.ZipInfo("SKILL.md", date_time=(1980, 1, 1, 0, 0, 0))
        member.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(member, skill_md)
    bundle = buffer.getvalue()
    tool_dsl = {
        "version": "0.1.0",
        "kind": "agent-studio-tool",
        "tool": {
            "type": "skill",
            "source_id": SOURCE_ID,
            "skill": {
                "slug": "turtle-to-sparql-update",
                "display_name": "Turtle to SPARQL Update",
                "description": "T-box·A-box Turtle을 SPARQL INSERT DATA로 변환합니다. 저장소 실행은 하지 않습니다.",
                "icon": "ri-code-s-slash-line",
                "icon_bg": "violet",
                "is_enabled": True,
                "bundle_base64": base64.b64encode(bundle).decode("ascii"),
                "bundle_sha256": hashlib.sha256(bundle).hexdigest(),
            },
            "dependencies": {},
        },
    }
    OUTPUT.write_text(yaml.safe_dump(tool_dsl, allow_unicode=True, sort_keys=False), encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
