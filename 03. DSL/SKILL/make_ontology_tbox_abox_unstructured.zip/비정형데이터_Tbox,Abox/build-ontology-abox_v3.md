---
name: build-ontology-abox
description: T-box Turtle, 엔티티 추출 JSON, CQ, ORSD를 입력받아 사전 색인된 정형·비정형 소스데이터에서 T-box의 클래스와 속성에 맞는 개체와 속성 값을 찾고, 원문 근거를 개체에 붙인 OWL Turtle로 출력한다. 온톨로지 생성의 3단계에서 문서 검색·조회 도구로 실제 제품, 작업지시, 조직, 인물 등의 개체와 속성 단언을 채울 때 사용한다.
---

# 온톨로지 A-box 구축

## 목적과 입력

T-box를 통해 개체의 종류와 채울 속성을 파악하고, 엔티티 추출 JSON을 통해 찾아야 할 개별 대상을 확인한다. CQ는 어떤 관계와 값을 우선 채울지 정하는 데, ORSD는 업무 범위와 사용할 소스데이터를 확인하는 데 사용한다. 네 입력을 함께 사용하여 사전 색인된 정형·비정형 소스데이터에서 개체와 속성 값을 찾고 T-box 어휘에 맞는 A-box를 작성한다.

- **입력:** T-box Turtle, 엔티티 추출 JSON, CQ 목록, ORSD.
- **소스데이터:** ORSD가 지정한 사전 색인 자료와 사용자가 해당 작업에 제공한 자료.
- **산출물:** T-box 어휘로 적은 개체와 속성 단언, 각 개체를 뒷받침하는 원문 근거를 담은 OWL Turtle.

T-box가 누락되면 필요한 입력을 요청한다. 엔티티 추출 JSON이 없으면 CQ와 T-box 클래스의 `rdfs:label`로 탐색 대상을 정한다. ORSD의 소스데이터 범위가 모호하면 확인 가능한 자료를 먼저 살펴보고 필요한 범위를 질문한다. T-box는 읽기만 하고 수정하지 않으며, T-box에 없는 클래스나 속성이 필요한 사실은 A-box에 넣지 않는다.

## 절차

1. T-box에서 클래스마다 IRI, `rdfs:label`, 식별자 속성, 이름 속성, 데이터 속성, 객체 속성을 확인하고, 속성마다 `rdfs:domain`과 `rdfs:range`를 확인한다. 이름이 `Id`로 끝나고 range가 `xsd:string`인 데이터 속성을 그 클래스의 우선 식별자 속성으로 본다. 이름이 `Id`, `Name`, `Status`, `Result`, `At`, `On`으로 끝나는 데이터 속성은 개체 하나에 값이 하나인 단일값 속성으로 본다. PROV-O 클래스는 개체의 직접 type으로 사용하지 않는다.
2. 엔티티 JSON의 키를 T-box 클래스의 `rdfs:label`과 비교하여 각 값을 해당 클래스의 탐색 대상으로 둔다(`"작업지시서": ["WO-260921-001"]` → 라벨이 "작업지시서"인 클래스). 라벨이 정확히 같은 클래스가 없으면 ORSD의 용어와 CQ 문맥으로 의미가 같은 클래스를 찾고, 확인할 수 없으면 그 키는 사용하지 않는다. 엔티티 JSON에 없더라도 CQ의 답에 필요한 클래스는 라벨과 CQ 문장으로 탐색 대상을 추가한다.
3. 탐색 대상별로 소스데이터를 검색한다. 식별값, 코드, 번호, 고유명은 원문 표기 그대로 `abox_search_keyword`에 넣는다. 관계, 상태, 업무 의미처럼 의미로 찾아야 하면 `abox_search_semantic`을 사용한다. 한 클래스의 여러 개체가 표, 목록, 대장에 모여 있으면 `abox_read_documents`로 그 구간을 끝까지 읽고 행별 값을 확인한다. 값의 소속이나 문맥이 불분명하면 `abox_read_documents`의 `position`에 검색 결과의 `section_chunk_id`를 넣어 앞뒤 섹션을 읽는다. 별도의 문서 읽기 도구가 제공된 환경에서는 해당 도구로 원문을 확인한다. 아래 도구 규격에 따라 인자와 결과를 처리한다. 상세 규격은 ZIP에 동봉된 `references/tools.md`에도 있다.
4. 원문에서 후보 단언을 기록한다. 후보마다 주어 개체, 주어 클래스, 속성, 값, 값의 datatype 또는 연결 대상 클래스, `section_chunk_id`, 근거 인용문을 내부적으로 관리한다. 인용문은 사실을 직접 확인할 수 있는 원문의 연속 구간을 그대로 옮기며 200자 이하로 한다. 인용문에 객체 속성의 연결 대상 식별값이나 이름이 있으면 그 개체의 식별자나 이름도 함께 후보로 기록한다. 정형데이터에서는 식별 컬럼과 속성값이 같은 행 또는 같은 레코드에 속하는지 확인한다. 엔티티 JSON, CQ, ORSD는 탐색 방향으로 사용하고, 값의 채택은 소스데이터의 본문을 기준으로 한다. 엔티티 JSON의 표기와 원문 표기가 다르면 원문 표기를 사용한다.
5. 후보 단언을 검증한다. 원문이 사실을 직접 뒷받침하고, 속성이 T-box에 있고, 주어 클래스가 domain과 일치하고, 데이터 속성 값이 range datatype에 맞고, 객체 속성의 연결 대상 클래스가 range와 일치하며 실제 개체로 채택되고, 근거 자료가 ORSD 범위 안에 있을 때만 채택한다. 원문이 "추정", "예상", "것으로 보인다"처럼 사실을 확정하지 않은 경우, 해석이나 추론 또는 새 계산을 해야 값이 나오는 경우, 단일값 속성에 서로 다른 값이 둘 이상 있어 확정할 수 없는 경우, 식별값도 이름도 없어 개체를 가리킬 수 없는 경우, 원문의 의미와 T-box 속성의 의미가 다른 경우에는 채택하지 않는다. 예를 들어 원문이 "재작업 대상 4대"뿐인데 속성이 `hasReworkCompletedQuantity`이면, 대상과 완료는 의미가 다르므로 값을 넣지 않는다.
6. 동일 개체를 정리하고 IRI를 정한다. 공식 식별번호가 있으면 이를 우선하고, 같은 클래스에서 식별값이 같은 개체는 하나로 합치며 서로 다른 원문 근거는 모두 유지한다. 식별값 없이 이름만 같은 두 개체는 합치지 않는다. IRI는 `adr:{Class}_{식별값}`이며, 식별값의 영문자, 숫자, 하이픈, 밑줄은 그대로 두고 나머지 문자는 하이픈으로 바꾼다. 식별값이 없으면 `adr:Company_n0001`처럼 클래스별 일련번호를 쓴다. 한글 이름을 로마자로 바꿔 IRI에 넣지 않는다.
7. 값을 T-box의 range에 맞게 표기한다. `xsd:string`은 `"값"`, `xsd:integer`는 `100`, `xsd:decimal`은 `12.5`, `xsd:boolean`은 `true`나 `false`, `xsd:date`는 `"YYYY-MM-DD"^^xsd:date`, `xsd:dateTime`은 `"YYYY-MM-DDThh:mm:ss"^^xsd:dateTime`으로 쓴다. 원문에 없는 연, 월, 일이나 시각을 보충하지 않는다. 상태와 결과 값은 원문의 핵심 표현을 쓴다("품질 보류 상태" → "품질 보류", "보류되었으며" → "보류").
8. 각 탐색 대상에 대해 관련 자료를 확인한 뒤 Turtle을 작성한다. 검색 결과가 부족하면 다른 원문 표기로 바꾸거나, 다른 검색 방식을 쓰거나, 앞뒤 섹션을 읽어 한 번 더 확인한다. 그래도 원문에서 확인되지 않은 값, 문서에 없는 속성, 엔티티 JSON에만 있고 소스데이터에서 확인되지 않은 개체나 값은 출력하지 않는다. 작업 중에는 탐색 대상별 진행 상황과 제외한 후보를 내부적으로 관리하고, 최종 출력에는 채택한 개체와 근거만 담는다.

## 도구 규격

세 도구는 사전 색인된 소스데이터의 원문 섹션을 조회한다. 호출할 때 각 도구의 필수 인자를 채우고, 반환된 식별자와 읽기 위치는 그대로 이어서 사용한다.

| 도구 | 인자 | 용도와 결과 |
|---|---|---|
| `abox_read_documents` | `document_hint` 선택, `position` 선택 | 두 인자가 비면 문서 목록을 반환한다. `document_hint`에 문서명 단서 또는 `document_id`를 넣으면 해당 문서를 읽는다. `position`에 `next_position`, `prev_position`, 검색 결과의 `section_chunk_id`를 넣으면 그 위치부터 읽는다. 원문은 `sections[].text`, 이어 읽을 위치는 `next_position`에 있다. |
| `abox_search_keyword` | `query` 필수, `document_id` 선택 | 원문에 적힌 낱말, 이름, 코드, 번호를 BM25로 검색한다. 엔티티 JSON의 식별값을 원문 표기 그대로 질의로 사용한다. 관련 섹션 최대 5건을 `results[]`로 돌려준다. |
| `abox_search_semantic` | `query` 필수, `document_id` 선택 | 뜻이 드러나는 문장으로 유사한 섹션을 검색한다. CQ 문장이나 "생산 로트가 제조된 설비"처럼 속성 의미를 풀어 쓴 문장을 질의로 사용할 수 있다. 관련 섹션 최대 5건을 `results[]`로 돌려준다. |

검색 결과의 `results[].text`에서 값을 확인하고, 근거 위치로 같은 결과의 `section_chunk_id`를 기록한다. 섹션 전체와 앞뒤 문맥이 필요하면 `section_chunk_id`를 `abox_read_documents.position`에 넣는다. `body_source`가 `child`인 결과도 이 방식으로 상위 섹션을 읽는다. 문서 목록의 `next_position`으로 다음 목록을, 읽기 결과의 `next_position`으로 다음 원문 구간을 이어서 확인한다.

결과의 `status`와 `warning`을 함께 읽는다. `success`이면 본문을 처리한다. `no_results`이면 문서에 쓰였을 다른 표기로 검색하거나 다른 검색 도구를 사용한다. `ambiguous`이면 반환된 후보의 `document_id`로 문서를 지정한다. `invalid_arguments`이면 안내된 인자를 고친다. `error`이면 `warning`에 나타난 설정 또는 연결 원인을 사용자에게 알린다.

## 출력 계약

최종 응답은 설명문 없이 `turtle` 코드 블록 하나로 작성한다. prefix는 `rdf`, `rdfs`, `owl`, `xsd`, `ado`, `adr`, `adm` 순서로 선언한다. `ado`는 T-box의 값을 그대로 쓰고, `adr`은 개체 네임스페이스, `adm`은 `adr`의 `resource/`를 `meta/`로 바꾼 값이다. 온톨로지 머리의 IRI는 `adr`에서 끝의 `/`를 뺀 값이며, `owl:imports`로 T-box 온톨로지 IRI를 가리킨다. 머리의 `rdfs:label`과 `rdfs:comment`에는 언어 태그를 달지 않고, `owl:versionInfo`는 `"0.0.1"`이다. 이어서 `adm:sourceChunk`와 `adm:sourceQuote`를 `owl:AnnotationProperty`로 선언한다.

개체는 T-box의 클래스 선언 순서대로 적는다. 각 개체는 `a ado:{Class}`, `rdfs:label`, 식별자 속성, 이름 속성, 기타 데이터 속성, 객체 속성, `adm:sourceChunk`, `adm:sourceQuote` 순서로 쓴다. `rdfs:label`은 이름 속성 값, 식별자 속성 값, 원문에서 개체를 가리키는 명칭 순으로 정하고 항상 `@ko`를 붙인다. 근거는 개체에 `adm:sourceChunk`와 `adm:sourceQuote`로 직접 붙이며, 여러 원문에서 확인된 개체는 두 속성에 값을 여럿 넣고 완전히 같은 근거는 중복하지 않는다. 들여쓰기는 공백 2칸이고, 세미콜론은 앞 값에 붙이며, 개체의 마지막 술어 뒤에 ` .`을 쓰고, 최상위 요소 사이에 빈 줄 하나를 둔다.

근거를 단언 단위로 표현하는 구문은 쓰지 않는다. `owl:Axiom`, `owl:annotatedSource`, `owl:annotatedProperty`, `owl:annotatedTarget`, `[]`나 `_:b1` 같은 blank node, `rdf:Statement` reification, RDF-star의 `<< ... >>`를 출력하지 않는다. `[] a owl:Axiom`에서 `[]`만 지운 `a owl:Axiom;`은 주어가 없어 Turtle 문법에도 어긋난다.

출력 전에 Turtle 문법을 확인한다. IRI는 `<...>` 또는 선언된 prefix로만 쓰고, 코드 블록 안에 `<[http://...](http://...)>` 같은 Markdown 링크 문법을 넣지 않는다. 문자열은 따옴표를 닫고, 내부의 `"`는 `\"`, 역슬래시는 `\\`로 이스케이프한다. 객체 속성의 값은 A-box 안에 선언된 개체 IRI이고, 데이터 속성의 값은 리터럴이다. `xsd:integer`와 `xsd:decimal`에는 따옴표를 붙이지 않고, `xsd:date`와 `xsd:dateTime`에는 datatype을 적는다. 사용한 `ado:` 클래스와 속성은 모두 T-box에 있어야 한다. 모든 statement는 `.`으로 끝나며, 결과가 길어도 문자열이나 statement를 중간에서 자르지 않는다. 전부 출력할 수 없으면 완전히 끝난 statement까지만 출력하고, 미완성 문자열, 미완성 IRI, 세미콜론으로 끝난 개체를 남기지 않는다. Turtle parser를 쓸 수 있으면 전체를 파싱하고 오류를 고친 뒤 다시 파싱한다.

```turtle
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix ado: <http://example.com/ontology/> .
@prefix adr: <http://example.com/resource/> .
@prefix adm: <http://example.com/meta/> .

<http://example.com/resource> a owl:Ontology;
  rdfs:label "제조온톨로지 인스턴스";
  rdfs:comment "제조온톨로지 T-box에 따라 생산 문서에서 추출한 인스턴스";
  owl:imports <http://example.com/ontology>;
  owl:versionInfo "0.0.1" .

adm:sourceChunk a owl:AnnotationProperty .

adm:sourceQuote a owl:AnnotationProperty .

adr:ProductionLot_L-2301 a ado:ProductionLot;
  rdfs:label "L-2301"@ko;
  ado:hasProductionLotId "L-2301";
  ado:manufacturedOnMachine adr:Machine_M-03;
  adm:sourceChunk "production-log-03#s02";
  adm:sourceQuote "로트 L-2301은 WO-2401에 따라 프레스 3호기(M-03)에서 생산되었다." .

adr:Machine_M-03 a ado:Machine;
  rdfs:label "프레스 3호기"@ko;
  ado:hasMachineId "M-03";
  ado:hasMachineName "프레스 3호기";
  adm:sourceChunk "production-log-03#s02";
  adm:sourceQuote "로트 L-2301은 WO-2401에 따라 프레스 3호기(M-03)에서 생산되었다." .
```

채택한 개체가 없으면 prefix, 온톨로지 머리, `adm:sourceChunk`와 `adm:sourceQuote` 선언까지만 출력하고, 마지막 statement도 `.`으로 끝낸다.
