---
name: build-ontology-tbox
description: CQ, ORSD, 1단계 엔티티 추출 JSON을 입력받아 사전 색인된 정형·비정형 소스데이터에서 개념의 정의와 구성을 확인하고, 온톨로지의 T-box(클래스, 객체 속성, 데이터 속성)를 PROV-O에 정렬한 OWL Turtle로 출력한다. 온톨로지 생성의 2단계에서 엔티티 종류를 클래스로, 식별값·이름·상태·일시와 대상 사이의 관계를 속성으로 정의할 때 사용한다.
---

# 온톨로지 T-box 구축

## 목적과 입력

CQ를 통해 답변에 필요한 개념, 관계, 값의 종류를 파악하고, ORSD를 통해 업무 범위, 소스데이터, 용어를 확인한다. 1단계 엔티티 추출 JSON의 키는 클래스 후보로, 값은 소스데이터에서 해당 개념이 쓰인 곳을 찾는 단서로 사용한다. 개념의 정의와 정형데이터의 컬럼 구성은 소스데이터의 본문에서 확인한다.

- **입력:** CQ 목록, ORSD, 1단계 엔티티 추출 JSON.
- **소스데이터:** ORSD가 지정한 사전 색인 자료와 사용자가 해당 작업에 제공한 자료.
- **산출물:** 클래스, 객체 속성, 데이터 속성만 담은 OWL Turtle. 개체(A-box)는 담지 않는다.

CQ 또는 ORSD가 누락되면 필요한 입력을 요청한다. 엔티티 추출 JSON이 없으면 CQ와 ORSD만으로 클래스를 정한다. ORSD의 소스데이터 범위가 모호하면 확인 가능한 자료를 먼저 살펴보고 필요한 범위를 질문한다. 사용자가 기존 T-box Turtle을 함께 주면 기존 요소의 IRI를 유지하고 새 요소만 추가하며, `owl:versionInfo`의 마지막 자리를 1 올린다.

## 절차

1. CQ마다 답변에 등장할 개념, 관계, 값의 종류를 적는다. ORSD의 범위와 용어, 엔티티 JSON의 키를 대조하여 요소를 판정한다. 여러 대상을 묶는 명사는 클래스로 둔다. 번호, 이름, 상태, 결과, 일시, 수량은 데이터 속성으로 둔다. 두 대상 사이의 관계는 객체 속성으로 둔다. 관계에 수량이나 시각, 셋째 참여자가 붙으면 그 관계를 클래스로 만든다. 엔티티 JSON의 값(TH-100, 온담디바이스 같은 개별 대상)은 T-box에 넣지 않는다. ORSD 범위 밖의 개념은 CQ에 나와도 만들지 않는다.
2. 소스데이터에서 개념의 정의와 구성을 확인한다. 정의와 설명은 `abox_search_semantic`에 "{개념}은 무엇인가"처럼 질의하여 찾는다. 표 머리글, 컬럼명, 코드 체계는 `abox_search_keyword`로 찾는다. 엔티티 JSON의 값을 `abox_search_keyword`의 질의로 쓰면 그 대상이 등장하는 표와 문장을 바로 찾을 수 있고, 같은 행이나 문장에 함께 나온 값과 대상에서 속성 후보를 얻는다. 문맥이 불분명하면 `abox_read_documents`의 `position`에 검색 결과의 `section_chunk_id`를 넣어 앞뒤 섹션을 읽는다. 별도의 문서 읽기 도구가 제공된 환경에서는 해당 도구로 원문을 확인한다. 아래 도구 규격에 따라 인자와 결과를 처리한다. 상세 규격은 ZIP에 동봉된 `references/tools.md`에도 있다.
3. 확인한 구성을 속성 후보로 옮긴다. 정형데이터에서는 행의 식별 컬럼을 식별자 속성으로, 값 컬럼을 데이터 속성으로, 다른 표의 식별값을 가리키는 컬럼을 객체 속성으로 둔다. 비정형데이터에서는 두 대상 사이의 관계를 서술한 문장을 객체 속성의 근거로 삼는다. CQ가 쓰지 않는 컬럼과 관계는 속성으로 만들지 않는다. 소스데이터에서 확인되지 않고 CQ에만 나온 개념은 CQ 문맥으로 정의하여 만든다.
4. 모든 클래스를 PROV-O 클래스 하나 아래에 둔다. 아래 표에서 위부터 처음 맞는 것을 고른다. 설비와 장비는 사람이 쓰는 대상이므로 Entity로 둔다.

   | 순서 | 대상 | 상위 클래스 | 예 |
   |---|---|---|---|
   | 1 | 사람 | `ns1:Person` | 직원 |
   | 2 | 조직, 회사, 부서 | `ns1:Organization` | 공급업체, 회사 |
   | 3 | 시간 동안 일어나며 대상을 쓰거나 만들거나 바꾸는 일과 그 기록 | `ns1:Activity` | 검사, 자재 소비 |
   | 4 | 해야 할 일의 지시, 계획, 절차 | `ns1:Plan` | 작업지시서 |
   | 5 | 같은 조건으로 관리되는 구성원의 묶음 | `ns1:Collection` | 생산 로트, 자재 로트 |
   | 6 | 그 밖의 물리적, 디지털, 개념적 대상 | `ns1:Entity` | 제품, 설비, 자재 |

5. 속성을 설계한다. 모든 클래스에 식별자 속성 `has{Class}Id`(xsd:string)를 하나 만든다. 이름은 `has{Class}Name`, 상태는 `has{Class}Status`, 결과는 `has{Class}Result`(모두 xsd:string), 일시는 `{과거분사}At`(xsd:dateTime), 날짜는 `{과거분사}On`(xsd:date), 수량은 xsd:integer나 xsd:decimal로 만든다. 식별값은 숫자로만 되어 있어도 xsd:string이다. 상태와 결과는 클래스로 만들지 않는다. 객체 속성은 CQ가 주로 묻는 방향으로 domain을 정하고, 동사나 과거분사로 시작해 range 클래스 이름으로 끝나게 짓는다(`manufacturedOnMachine`). 모든 속성은 domain과 range를 하나씩 가진다. 역속성은 CQ가 양방향으로 물을 때만 만들고, 두 속성 모두에 `owl:inverseOf`를 적는다.
6. 이름, 라벨, 문형을 정한다. 클래스는 영문 UpperCamelCase 단수 명사, 속성은 영문 lowerCamelCase로 쓰고 약어는 `Id`처럼 첫 글자만 대문자로 쓴다. 한글 발음을 로마자로 옮기지 않는다. 엔티티 JSON의 키에서 온 클래스는 그 키를 `rdfs:label`로 그대로 쓴다. 3단계 A-box 구축이 이 라벨로 엔티티 JSON의 키와 클래스를 잇기 때문이다. 그 밖의 클래스와 속성의 라벨은 ORSD와 소스데이터의 대표 표기로 정한다. 모든 요소에 `rdfs:label`과 `rdfs:comment`를 `@ko`로 하나씩 단다. comment는 소스데이터에서 확인한 정의를 아래 문형에 맞춰 쓰고, 정의를 찾지 못하면 CQ 문맥으로 쓴다. 클래스는 정의 명사구로, 객체 속성은 "~를 나타낸다.", 식별자 속성은 "~를 고유하게 식별하는 값.", 이름 속성은 "~에 부여된 명칭."으로 쓴다. 두 요소가 같은 IRI나 같은 라벨을 갖지 않게 한다.
7. 완성한 T-box를 점검한다. CQ마다 T-box 요소만으로 SPARQL 질의를 구성할 수 있는지 확인한다. 속성의 domain과 range가 선언된 클래스인지, 모든 클래스가 PROV-O에 닿는지, 식별자 속성이 빠진 클래스가 없는지, 역속성이 양쪽에 있는지, 엔티티 JSON의 키 가운데 클래스가 되어야 할 것이 빠지지 않았는지 확인한다. 고칠 수 없거나 CQ, ORSD, 소스데이터에 근거가 없는 요소는 빼고, 애매한 요소는 넣지 않는다. `owl:Restriction`, `owl:disjointWith`, 속성 특성(`owl:FunctionalProperty` 등), `owl:unionOf`, 별도 주석 속성은 ORSD가 명시적으로 요구하지 않으면 쓰지 않는다. 작업 중에는 CQ별 사용 요소, 요소별 근거 섹션, 점검 결과를 내부적으로 관리하고, 최종 출력에는 T-box만 담는다. 점검을 마치면 출력 계약의 형식으로 Turtle을 작성한다.

## 도구 규격

세 도구는 사전 색인된 소스데이터의 원문 섹션을 조회한다. 호출할 때 각 도구의 필수 인자를 채우고, 반환된 식별자와 읽기 위치는 그대로 이어서 사용한다. T-box 구축에서는 개념의 정의와 정형데이터의 구성을 확인하는 데 사용하고, 개별 값을 모으지 않는다.

| 도구 | 인자 | 용도와 결과 |
|---|---|---|
| `abox_read_documents` | `document_hint` 선택, `position` 선택 | 두 인자가 비면 문서 목록을 반환한다. `document_hint`에 문서명 단서 또는 `document_id`를 넣으면 해당 문서를 읽는다. `position`에 `next_position`, `prev_position`, 검색 결과의 `section_chunk_id`를 넣으면 그 위치부터 읽는다. 원문은 `sections[].text`, 이어 읽을 위치는 `next_position`에 있다. |
| `abox_search_keyword` | `query` 필수, `document_id` 선택 | 원문에 적힌 낱말, 이름, 코드, 번호를 BM25로 검색한다. 관련 섹션 최대 5건을 `results[]`로 돌려준다. |
| `abox_search_semantic` | `query` 필수, `document_id` 선택 | 뜻이 드러나는 문장으로 유사한 섹션을 검색한다. 개념의 정의를 찾을 때 "{개념}은 무엇인가"처럼 질의한다. CQ 문장을 질의로 사용할 수 있다. 관련 섹션 최대 5건을 `results[]`로 돌려준다. |

검색 결과의 `results[].text`에서 정의와 구성을 확인한다. 표 전체나 앞뒤 문맥이 필요하면 같은 결과의 `section_chunk_id`를 `abox_read_documents.position`에 넣는다. `body_source`가 `child`인 결과도 이 방식으로 상위 섹션을 읽는다. 문서 목록의 `next_position`으로 다음 목록을, 읽기 결과의 `next_position`으로 다음 원문 구간을 이어서 확인한다.

결과의 `status`와 `warning`을 함께 읽는다. `success`이면 본문을 처리한다. `no_results`이면 문서에 쓰였을 다른 표기로 검색하거나 다른 검색 도구를 사용한다. `ambiguous`이면 반환된 후보의 `document_id`로 문서를 지정한다. `invalid_arguments`이면 안내된 인자를 고친다. `error`이면 `warning`에 나타난 설정 또는 연결 원인을 사용자에게 알린다.

## 출력 계약

최종 응답은 설명문 없이 ` ```turtle ` 코드 블록 하나로 작성한다. 아래 순서와 표기를 지킨다.

1. prefix 7개를 `rdf`, `rdfs`, `owl`, `xsd`, `ado`, `adr`, `ns1` 순서로 선언한다. `ado`는 `http://example.com/ontology/`, `adr`은 `http://example.com/resource/`, `ns1`은 `http://www.w3.org/ns/prov#`이다. ORSD가 네임스페이스를 정하면 `ado`와 `adr`의 IRI만 바꾼다.
2. 온톨로지 머리를 적는다. IRI는 `ado` 네임스페이스에서 끝의 `/`를 뺀 값이고, `rdfs:label`과 `rdfs:comment`에는 언어 태그를 달지 않는다. 새 T-box의 `owl:versionInfo`는 `"0.0.1"`이다.
3. 도메인 클래스를 적는다. 각 클래스는 label, comment, subClassOf 순이다.
4. 사용한 PROV-O 클래스를 처음 쓰인 순서대로 선언하고, 각 클래스 바로 뒤에 그 상위 클래스를 선언한다. 라벨 없이 `rdfs:subClassOf`만 적는다. `Collection`과 `Plan`의 상위는 `Entity`, `Person`과 `Organization`의 상위는 `Agent`이며, `Entity`, `Agent`, `Activity`는 상위가 없다. 쓰지 않은 PROV-O 클래스는 선언하지 않는다.
5. 속성을 도메인 클래스 순서대로 적고, 클래스 안에서는 식별자 속성을 먼저 적는다. 각 속성은 label, comment, domain, range, inverseOf 순이다.
6. 들여쓰기는 공백 2칸이고, `a owl:Class;`처럼 세미콜론을 앞 말에 붙이며, 마지막 술어 뒤에 ` .`을 쓴다. 요소 사이에는 빈 줄 하나를 둔다.

```turtle
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix ado: <http://example.com/ontology/> .
@prefix adr: <http://example.com/resource/> .
@prefix ns1: <http://www.w3.org/ns/prov#> .

<http://example.com/ontology> a owl:Ontology;
  rdfs:label "제조온톨로지";
  rdfs:comment "제조온톨로지";
  owl:versionInfo "0.0.1" .

ado:ProductionLot a owl:Class;
  rdfs:label "생산 로트"@ko;
  rdfs:comment "동일한 생산 공정이나 조건에 따라 함께 제조된 제품의 묶음."@ko;
  rdfs:subClassOf ns1:Collection .

ado:Machine a owl:Class;
  rdfs:label "설비"@ko;
  rdfs:comment "제조 작업에 사용되는 기계 또는 생산 설비."@ko;
  rdfs:subClassOf ns1:Entity .

ns1:Collection a owl:Class;
  rdfs:subClassOf ns1:Entity .

ns1:Entity a owl:Class .

ado:hasProductionLotId a owl:DatatypeProperty;
  rdfs:label "생산 로트 식별자"@ko;
  rdfs:comment "생산 로트를 고유하게 식별하는 값."@ko;
  rdfs:domain ado:ProductionLot;
  rdfs:range xsd:string .

ado:manufacturedOnMachine a owl:ObjectProperty;
  rdfs:label "제조 설비"@ko;
  rdfs:comment "생산 로트가 제조된 설비를 나타낸다."@ko;
  rdfs:domain ado:ProductionLot;
  rdfs:range ado:Machine .

ado:hasMachineId a owl:DatatypeProperty;
  rdfs:label "설비 식별자"@ko;
  rdfs:comment "설비를 고유하게 식별하는 값."@ko;
  rdfs:domain ado:Machine;
  rdfs:range xsd:string .

ado:hasMachineName a owl:DatatypeProperty;
  rdfs:label "설비명"@ko;
  rdfs:comment "설비에 부여된 명칭."@ko;
  rdfs:domain ado:Machine;
  rdfs:range xsd:string .
```

클래스가 하나도 확정되지 않으면 prefix와 온톨로지 머리만 담은 Turtle을 출력한다.
