---
name: build-sql-ontology-abox
description: 2단계 정형 T-box Turtle의 원본 테이블·컬럼 매핑을 따라 관계형 DB의 실제 행을 조회하여 온톨로지 A-box(개체와 속성 단언)를 만들고, 원본 테이블과 행 키를 개체에 붙인 OWL Turtle로 출력한다. t2sql MCP의 sql_run으로 이미 연결된 DB를 읽으며, 1단계 정형 인스턴스 후보 JSON과 CQ·ORSD가 있으면 대상 행 범위를 정하는 데 사용하는 온톨로지 구축 3단계에 사용한다.
---

# 정형 데이터 A-box 구축

## 목적과 입력

- 입력: 2단계 T-box Turtle(`adm:sourceTable`, `adm:sourceColumn` 매핑 포함), 1단계 정형 인스턴스 후보 JSON, 대상 DB. CQ·ORSD가 주어지면 함께 사용한다. 사용자가 지정한 DB·스키마·테이블 범위를 우선한다.
- 연결: 반드시 `sql_run`으로 DB에 연결하여 실제 행을 조회한다. 사용자에게 연결 URL·계정·비밀번호를 먼저 요구하지 않는다. 도구 호출 결과 실제로 연결되지 않거나 필수 인자가 빠진 경우에만 부족한 정보를 묻는다.
- 대상: T-box 매핑에 적힌 테이블의 실제 행. 1단계 JSON이 있으면 그 후보 값의 행과, 그 행이 객체 속성으로 가리키는 행을 대상으로 한다. 없으면 ORSD 범위 안의 매핑 테이블 전체 행을 대상으로 한다.
- 출력: T-box 어휘로 적은 개체와 속성 단언, 각 개체의 원본 테이블과 행 키를 담은 OWL Turtle 하나.
- 목적: DB에 실제로 저장된 행과 값만으로 A-box를 만든다. T-box는 읽기만 하고 수정하지 않는다.

T-box가 누락되거나 매핑 주석이 없으면 필요한 입력을 요청한다. T-box에 없는 클래스나 속성이 필요한 값은 A-box에 넣지 않는다.

## 절차

1. **T-box 해석**
   - 클래스마다 IRI, `rdfs:label`, `adm:sourceTable`, 식별자 속성(이름이 `Id`로 끝나고 range가 `xsd:string`인 데이터 속성)과 그 `adm:sourceColumn`을 확인한다.
   - 속성마다 domain, range, `adm:sourceColumn`을 확인한다. `>` 가 있는 매핑은 코드 표시명 조인, `+`가 있는 매핑은 복합키, 대괄호는 추가 조인 조건이다.
   - 이름이 `Id`, `Name`, `Status`, `Result`, `At`, `On`으로 끝나는 데이터 속성은 개체 하나에 값이 하나인 단일값 속성으로 본다. PROV-O 클래스는 개체의 직접 type으로 사용하지 않는다.
2. **대상 행 범위 선정**
   - 1단계 JSON의 후보 종류를 T-box 클래스의 `rdfs:label`과 대조하여 각 값을 해당 클래스의 대상 행으로 둔다. 라벨이 정확히 같은 클래스가 없으면 같은 테이블의 클래스 가운데 의미가 같은 것을 찾고, 확인할 수 없으면 그 후보 종류는 사용하지 않는다.
   - 1단계 값이 `원본테이블 / 결합키` 형식이면 결합키를 복합키 컬럼 순서로 나눠 행을 찾는다.
   - 대상 행이 객체 속성으로 가리키는 행도 대상에 넣는다. CQ의 답에 필요한 클래스가 1단계 JSON에 없으면 그 클래스의 매핑 테이블에서 CQ 조건으로 대상 행을 정한다.
3. **매핑 확인**
   - `sql_run`으로 매핑에 적힌 테이블과 컬럼이 실제로 있는지, 자료형이 range와 맞는지 확인한다. 없는 컬럼의 속성은 채우지 않는다.
   - 대상 테이블마다 전체 건수와 대상 행 건수를 조회한다.
4. **조회와 수집**
   - 클래스마다 식별자 컬럼과 그 클래스를 domain으로 하는 속성의 컬럼을 한 번에 조회한다. 코드 표시명은 매핑의 조인 조건으로 코드 테이블을 조인해 읽는다.
   - 객체 속성은 원본 컬럼의 값을 읽고, range 클래스의 매핑 테이블에 그 식별값의 행이 있는지 `LEFT JOIN` 또는 `EXISTS`로 확인한다. 대상 행이 없거나 값이 NULL이면 관계를 만들지 않는다.
   - 컬럼 값에서 나온 클래스(`WORK_ORDER.LOT_NO`의 생산 로트)는 `SELECT DISTINCT`로 개체를 모으고, NULL은 뺀다.
   - 대량 결과는 전체 건수 확인 후 식별키 정렬과 페이지 분할로 끝까지 읽는다. 샘플 조회나 임의 `LIMIT`를 완결된 수집으로 취급하지 않는다. 도구가 실제 반환한 행 수와 잘림·다음 페이지 표시를 확인한다.
   - 일대다 조인으로 행이 늘어나면 원본 키로 구별하고, 같은 개체의 값을 중복 기록하지 않는다.
5. **검증**
   - 값이 NULL이면 그 속성을 쓰지 않는다. 빈 문자열과 공백만 있는 값도 쓰지 않는다.
   - range로 변환할 수 없는 값(`xsd:integer` 속성의 소수, 날짜 형식이 아닌 문자열)은 쓰지 않는다.
   - 단일값 속성에 한 개체의 값이 둘 이상 나오면(한 로트 번호가 여러 작업지시 행에 다른 값으로 있음) 그 속성의 값을 모두 쓰지 않는다.
   - 합계·평균·차이처럼 DB에 저장되지 않은 값을 SQL로 계산해 넣지 않는다. 계획·실적·재검사 수량은 매핑된 컬럼의 값만 쓴다.
   - 객체 속성의 대상 개체가 이 A-box에 없으면 관계를 쓰지 않는다. 누락된 행을 임의로 만들어 채우지 않는다.
6. **IRI 생성**
   - IRI는 `adr:{Class}_{식별값}`이다. 식별값의 영문자, 숫자, 하이픈, 밑줄은 그대로 두고 나머지 문자는 하이픈으로 바꾸며, 이어진 하이픈은 하나로 줄이고 끝의 하이픈은 뺀다.
   - 복합키 개체의 식별값은 키 컬럼 값을 매핑 순서대로 ` / `로 이은 문자열이다. 식별자 속성에는 이 문자열을 그대로 쓰고, IRI는 위 규칙으로 바꾼다(`MC-260929-003 / MAT-SEN-001` → `adr:MaterialConsumption_MC-260929-003-MAT-SEN-001`).
   - 식별값이 비어 있는 행은 개체로 만들지 않는다. 한글 식별값을 로마자로 바꿔 IRI에 넣지 않으며, 한글만 있는 식별값은 `adr:{Class}_n0001`부터 클래스별 일련번호를 쓴다.
   - 같은 클래스에서 식별값이 같은 개체는 하나로 합치고, 원본 행 키는 모두 남긴다.
7. **값 표기**
   - `xsd:string`은 `"값"`, `xsd:integer`는 `100`, `xsd:decimal`은 `12.5`, `xsd:boolean`은 `true`나 `false`, `xsd:date`는 `"YYYY-MM-DD"^^xsd:date`, `xsd:dateTime`은 `"YYYY-MM-DDThh:mm:ss"^^xsd:dateTime`으로 쓴다.
   - 문자열은 DB 값의 앞뒤 공백만 지우고 그대로 쓴다. 소수는 DB 값의 자릿수를 유지한다. 일시의 소수 초는 버리고, 시간대는 DB에 저장된 경우에만 붙인다.
8. **근거 연결**
   - 모든 개체에 `adm:sourceTable`로 원본 테이블 이름을, `adm:sourceKey`로 행 키를 붙인다. 행 키는 `"컬럼=값"` 형식이고, 복합키는 `"컬럼1=값1, 컬럼2=값2"`로 쓴다.
   - 여러 행에서 나온 개체(여러 작업지시 행의 같은 로트 번호)는 `adm:sourceKey`에 값을 여럿 넣는다. 같은 키는 중복하지 않는다.
   - 작업 중에는 클래스별 대상 건수, 읽은 고유 키 건수, 제외한 값과 사유를 내부적으로 관리하고, 최종 출력에는 채택한 개체와 근거만 담는다.

## `sql_run` 사용

- 실행 시작 시 제공된 `sql_run`을 실제로 호출해 연결 및 접근 범위를 확인한다. 이미 연결된 MCP 도구에 별도 SQLAlchemy URL을 요구하거나 도구 밖의 직접 접속을 선행하지 않는다.
- 실제 도구 스키마와 응답 형식을 확인한 뒤 그 인자에 맞춰 호출한다. 문서에 없는 필수 인자·응답 필드·고정 조회 상한을 가정하지 않는다.
- 데이터 조회는 읽기 전용 SQL로 수행한다. 조회를 위해 테이블·뷰·프로시저를 생성하거나 데이터를 변경하지 않는다.
- 실행 SQL의 테이블·컬럼·조인·필터는 T-box 매핑과 확인된 DB 구조, 요청 범위·CQ 조건에서 도출한다.
- `sql_run`이 없거나 연결·조회가 실패하면 A-box를 완성한 것처럼 답하지 않는다. SQL 덤프, 스프레드시트, 문서나 추정값으로 대체하지 않는다. 도구 부재 또는 실제 오류와 필요한 조치만 알린다.
- SQL 오류는 메시지에 따라 스키마·권한·방언·컬럼·조인을 수정하고 재실행한다. 접근 제한 또는 호출 제한으로 완료하지 못하면 확인한 범위와 남은 범위를 사용자에게 알린다.

## 출력 계약

최종 응답은 설명문 없이 `turtle` 코드 블록 하나로 작성한다. prefix는 `rdf`, `rdfs`, `owl`, `xsd`, `ado`, `adr`, `adm` 순서로 선언하고, 세 네임스페이스는 T-box의 값을 그대로 쓴다. 온톨로지 머리의 IRI는 `adr`에서 끝의 `/`를 뺀 값이며, `owl:imports`로 T-box 온톨로지 IRI를 가리킨다. 머리의 `rdfs:label`과 `rdfs:comment`에는 언어 태그를 달지 않고, `owl:versionInfo`는 `"0.0.1"`이다. 이어서 `adm:sourceTable`과 `adm:sourceKey`를 `owl:AnnotationProperty`로 선언한다.

개체는 T-box의 클래스 선언 순서대로, 클래스 안에서는 식별값 순서대로 적는다. 각 개체는 `a ado:{Class}`, `rdfs:label`, 식별자 속성, 이름 속성, 기타 데이터 속성, 객체 속성, `adm:sourceTable`, `adm:sourceKey` 순서로 쓴다. `rdfs:label`은 이름 속성 값, 없으면 식별값으로 정하고 항상 `@ko`를 붙인다. 들여쓰기는 공백 2칸이고, 세미콜론은 앞 값에 붙이며, 개체의 마지막 술어 뒤에 ` .`을 쓰고, 최상위 요소 사이에 빈 줄 하나를 둔다.

근거를 단언 단위로 표현하는 구문은 쓰지 않는다. `owl:Axiom`, `owl:annotatedSource`, `owl:annotatedProperty`, `owl:annotatedTarget`, `[]`나 `_:b1` 같은 blank node, `rdf:Statement` reification, RDF-star의 `<< ... >>`를 출력하지 않는다.

출력 전에 Turtle 문법을 확인한다. IRI는 `<...>` 또는 선언된 prefix로만 쓰고, 코드 블록 안에 Markdown 링크 문법을 넣지 않는다. 문자열 내부의 `"`는 `\"`, 역슬래시는 `\\`로 이스케이프한다. 객체 속성의 값은 A-box 안에 선언된 개체 IRI이고, 데이터 속성의 값은 리터럴이다. 사용한 `ado:` 클래스와 속성은 모두 T-box에 있어야 한다. 모든 statement는 `.`으로 끝나며, 결과가 길어도 문자열이나 statement를 중간에서 자르지 않는다. Turtle parser를 쓸 수 있으면 전체를 파싱하고 오류를 고친 뒤 다시 파싱한다.

출력 크기나 도구 제한으로 대상 범위 전체를 담지 못하면, 코드 블록의 prefix 선언 바로 앞에 `# 미완료:`로 시작하는 Turtle 주석 줄을 두어 클래스별 대상 건수, 출력한 건수, 남은 범위를 적는다. 그리고 완전히 끝난 개체까지만 출력한다.

```turtle
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix ado: <http://example.com/ontology/> .
@prefix adr: <http://example.com/resource/> .
@prefix adm: <http://example.com/meta/> .

<http://example.com/resource> a owl:Ontology;
  rdfs:label "제조온톨로지 인스턴스";
  rdfs:comment "제조 ERP의 WORK_ORDER, PRODUCT 테이블에서 추출한 인스턴스";
  owl:imports <http://example.com/ontology>;
  owl:versionInfo "0.0.1" .

adm:sourceTable a owl:AnnotationProperty .

adm:sourceKey a owl:AnnotationProperty .

adr:WorkOrder_WO-260929-003 a ado:WorkOrder;
  rdfs:label "WO-260929-003"@ko;
  ado:hasWorkOrderId "WO-260929-003";
  ado:hasWorkOrderStatus "보류";
  ado:hasPlannedQuantity 500;
  ado:producesProduct adr:Product_TH-100;
  adm:sourceTable "WORK_ORDER";
  adm:sourceKey "WORK_ORDER_ID=WO-260929-003" .

adr:ProductionLot_LOT-TH100-260929-03 a ado:ProductionLot;
  rdfs:label "LOT-TH100-260929-03"@ko;
  ado:hasProductionLotId "LOT-TH100-260929-03";
  ado:generatedFromWorkOrder adr:WorkOrder_WO-260929-003;
  adm:sourceTable "WORK_ORDER";
  adm:sourceKey "WORK_ORDER_ID=WO-260929-003" .

adr:Product_TH-100 a ado:Product;
  rdfs:label "온습도 센서 TH-100"@ko;
  ado:hasProductId "TH-100";
  ado:hasProductName "온습도 센서 TH-100";
  adm:sourceTable "PRODUCT";
  adm:sourceKey "PRODUCT_ID=TH-100" .
```

채택한 개체가 없으면 prefix, 온톨로지 머리, 주석 속성 선언만 출력하고 마지막 statement도 `.`으로 끝낸다. `sql_run`이 없거나 조회에 실패하면 Turtle을 내지 않고 오류와 필요한 조치만 알린다.
