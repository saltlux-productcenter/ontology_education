---
name: build-sql-ontology-tbox
description: 1단계 정형 인스턴스 후보 JSON과 관계형 DB 스키마로 온톨로지 T-box(클래스, 객체 속성, 데이터 속성)를 설계하고, 각 요소의 원본 테이블·컬럼 매핑을 주석으로 붙인 PROV-O 정렬 OWL Turtle로 출력한다. t2sql MCP의 sql_run으로 이미 연결된 DB의 테이블·컬럼·키를 조회하며, CQ·ORSD가 있으면 범위 선정에 활용하는 온톨로지 구축 2단계에 사용한다.
---

# 정형 데이터 T-box 구축

## 목적과 입력

- 입력: 1단계 정형 인스턴스 후보 JSON(`테이블명: {후보 종류: [값]}`), 대상 DB 또는 업무 영역. CQ·ORSD가 주어지면 함께 사용한다. 사용자가 지정한 DB·스키마·테이블 범위를 우선한다.
- 연결: 반드시 `sql_run`으로 DB에 연결하여 메타데이터와 필요한 값 분포를 조회한다. 사용자에게 연결 URL·계정·비밀번호를 먼저 요구하지 않는다. 도구 호출 결과 실제로 연결되지 않거나 필수 인자가 빠진 경우에만 부족한 정보를 묻는다.
- 대상: 1단계 JSON에 나온 테이블과, 그 행을 잇는 중간 테이블·코드 테이블. ORSD가 있으면 그 소스데이터 범위를 따른다.
- 출력: 클래스, 객체 속성, 데이터 속성과 각 요소의 원본 테이블·컬럼 매핑(`adm:sourceTable`, `adm:sourceColumn`)을 담은 OWL Turtle 하나. 개체(A-box)는 담지 않는다.
- 목적: 3단계 A-box 구축이 매핑만 보고 SQL로 개체와 속성 값을 채울 수 있는 T-box를 만든다.

1단계 JSON이 없으면 CQ·ORSD와 DB 구조로 클래스를 정한다. 사용자가 기존 T-box Turtle을 함께 주면 기존 요소의 IRI를 유지하고 새 요소만 추가하며, `owl:versionInfo`의 마지막 자리를 1 올린다.

## 절차

1. **범위 선정**
   - 1단계 JSON의 테이블과 후보 종류를 모은다. CQ·ORSD가 있으면 답의 대상·연결 기록·기간·판정 조건과 대조하고, 범위 밖 테이블은 뺀다.
   - 후보 행을 서로 잇는 중간 테이블과, 분류값의 표시명을 가진 코드 테이블을 범위에 넣는다.
2. **DB 구조 확인**
   - `sql_run`으로 DB 종류와 현재 스키마를 확인하고, 범위 테이블의 컬럼·자료형·NULL 허용·기본키·외래키·테이블과 컬럼 주석을 조회한다. DB별 카탈로그와 SQL 문법을 확인하여 사용한다.
   - 키가 선언되지 않았으면 실제 유일성과 결합 컬럼을 데이터로 점검한다. 외래키가 선언되지 않은 연결은 값의 포함 관계를 조회로 확인한 경우에만 관계로 본다. 이름이 비슷한 컬럼만으로 관계를 단정하지 않는다.
   - 분류·상태 컬럼은 `DISTINCT` 값과 코드 테이블의 표시명을 확인한다.
3. **클래스 판정**
   - 1단계 후보 종류 하나가 클래스 하나다. 후보 종류 이름을 클래스의 `rdfs:label`로 그대로 쓴다. 3단계가 이 라벨로 1단계 JSON과 클래스를 잇는다.
   - 개별 대상 테이블(직원·조직·제품·자재·설비)은 기본키 행이 개체인 클래스로 둔다.
   - 기록·사건 테이블(자재 투입, 검사 결과, 인사발령처럼 대상·일시·상태를 함께 가진 행)은 클래스로 둔다. 복합키 연결 행도 CQ에 필요한 독립 기록이면 클래스로 둔다.
   - 두 외래키만 있고 다른 컬럼이 없는 순수 연결 테이블은 클래스로 만들지 않고 두 클래스 사이의 객체 속성으로 둔다.
   - 한 테이블에 후보 종류가 둘 이상이면(`WORK_ORDER`의 작업지시와 생산 로트), 기본키가 가리키는 대상을 주 클래스로 두고, 다른 컬럼 값으로 가리키는 대상은 CQ가 대상으로 묻거나 다른 테이블이 참조할 때만 별도 클래스로 둔다. 그렇지 않으면 주 클래스의 데이터 속성으로 둔다.
   - 분류값(역할·유형·상태)은 클래스로 만들지 않고, 그 값을 가진 클래스의 `xsd:string` 데이터 속성으로 둔다. ORSD가 분류 체계 자체를 관리 대상으로 요구할 때만 클래스로 둔다.
   - 규칙·기준 행(검사 한계, 급여 기준)은 클래스로 둔다.
4. **PROV-O 정렬**
   - 모든 클래스를 PROV-O 클래스 하나 아래에 둔다. 아래 표에서 위부터 처음 맞는 것을 고른다. 설비와 장비는 `ns1:Entity`로 둔다.

   | 순서 | 대상 | 상위 클래스 | 예 |
   |---|---|---|---|
   | 1 | 사람 | `ns1:Person` | 직원 |
   | 2 | 조직, 회사, 부서 | `ns1:Organization` | 공급업체, 부서 |
   | 3 | 기록·사건 행 | `ns1:Activity` | 자재 투입 기록, 검사 결과 |
   | 4 | 해야 할 일의 지시, 계획, 절차 | `ns1:Plan` | 작업지시 |
   | 5 | 같은 조건으로 관리되는 구성원의 묶음 | `ns1:Collection` | 생산 로트, 자재 로트 |
   | 6 | 그 밖의 대상과 규칙·기준 | `ns1:Entity` | 제품, 설비, 자재, 검사 기준 |

5. **속성 설계**
   - 모든 클래스에 식별자 속성 `has{Class}Id`(`xsd:string`)를 하나 만든다. 숫자 키도 `xsd:string`이다. 복합키 클래스도 식별자 속성은 하나이며, 값은 3단계에서 키 컬럼 값을 ` / `로 이어 만든다.
   - 값 컬럼은 데이터 속성으로 둔다. 이름은 `has{Class}Name`, `has{Class}Status`, `has{Class}Result`, `{과거분사}At`(일시), `{과거분사}On`(날짜) 패턴을 먼저 쓰고, 그 밖의 컬럼은 `has{컬럼 의미}`로 짓는다. range는 SQL 자료형으로 정한다.

     | SQL 자료형 | range |
     |---|---|
     | CHAR, VARCHAR, TEXT, 코드 | `xsd:string` |
     | INT, BIGINT, SMALLINT | `xsd:integer` |
     | DECIMAL, NUMERIC, FLOAT, DOUBLE | `xsd:decimal` |
     | BOOLEAN, BIT(1) | `xsd:boolean` |
     | DATE | `xsd:date` |
     | DATETIME, TIMESTAMP | `xsd:dateTime` |

   - 범위 클래스를 가리키는 외래키 컬럼은 객체 속성으로 둔다. domain은 외래키를 가진 쪽 클래스, range는 참조되는 클래스다. 동사나 과거분사로 시작해 range 클래스 이름으로 끝나게 짓는다(`producesProduct`). 코드 테이블을 가리키는 외래키는 객체 속성이 아니라 표시명을 담는 데이터 속성으로 둔다.
   - 계획·실적·재검사처럼 뜻이 다른 수량 컬럼은 컬럼마다 따로 속성을 만든다. 합계·평균처럼 DB에 저장되지 않은 값은 속성으로 만들지 않는다.
   - CQ가 있으면 CQ가 쓰는 컬럼만 속성으로 만든다. 없으면 식별키, 표시명, 분류·일시·수량·측정·상태, 연결키 컬럼만 만들고, 생성자·수정일시 같은 감사 컬럼은 뺀다.
   - 역속성은 CQ가 양방향으로 물을 때만 만들고, 두 속성 모두에 `owl:inverseOf`를 적는다.
6. **매핑 주석**
   - 모든 클래스에 `adm:sourceTable`로 개체를 읽을 테이블 이름을 적는다. 컬럼 값에서 나온 클래스는 그 컬럼이 있는 테이블을 적는다.
   - 모든 속성에 `adm:sourceColumn`으로 값을 읽을 위치를 적는다. 형식은 아래 셋 가운데 하나다.
     - 단일 컬럼: `"WORK_ORDER.PLAN_QTY"`
     - 복합키: `"MATERIAL_CONSUMPTION.WORK_ORDER_ID + MATERIAL_CONSUMPTION.MATERIAL_ID"`
     - 코드 표시명: `"WORK_ORDER.STATUS_CD > COMMON_CODE.CODE_NM [GROUP_CD='WO_STATUS']"`. `>` 왼쪽이 원본 컬럼, 오른쪽이 표시명 컬럼이며, 대괄호에는 코드 그룹 같은 추가 조인 조건을 적는다.
   - 객체 속성의 `adm:sourceColumn`은 domain 클래스의 원본 테이블에서 range 클래스의 식별값을 담은 컬럼이다.
7. **이름, 라벨, 문형**
   - 클래스는 테이블 이름을 영문 UpperCamelCase 단수로 바꾼다(`WORK_ORDER` → `WorkOrder`). `TB_` 같은 접두어는 뺀다. 속성은 영문 lowerCamelCase로 쓰고 약어는 `Id`처럼 첫 글자만 대문자로 쓴다. 한글 발음을 로마자로 옮기지 않는다.
   - 모든 요소에 `rdfs:label`과 `rdfs:comment`를 `@ko`로 하나씩 단다. 속성 라벨은 컬럼 주석을 우선하고, 없으면 컬럼 의미를 한국어로 쓴다. comment는 테이블·컬럼 주석을 아래 문형에 맞춰 쓰고, 주석이 없으면 CQ와 값 분포로 쓴다. 클래스는 정의 명사구로, 객체 속성은 "~를 나타낸다.", 식별자 속성은 "~를 고유하게 식별하는 값.", 이름 속성은 "~에 부여된 명칭."으로 쓴다.
   - 두 요소가 같은 IRI나 같은 라벨을 갖지 않게 한다.
8. **점검**
   - CQ마다 T-box 요소만으로 SPARQL 질의를 구성할 수 있는지 확인한다.
   - 속성의 domain과 range가 선언된 클래스인지, 모든 클래스가 PROV-O에 닿는지, 식별자 속성이 빠진 클래스가 없는지, 역속성이 양쪽에 있는지 확인한다.
   - 모든 클래스에 `adm:sourceTable`, 모든 속성에 `adm:sourceColumn`이 있고, 적힌 테이블과 컬럼이 DB에 실제로 있는지 확인한다. 객체 속성의 컬럼이 range 클래스의 식별값을 가리키는지 확인한다.
   - 1단계 후보 종류 가운데 클래스가 되어야 할 것이 빠지지 않았는지 확인한다.
   - 고칠 수 없거나 DB, CQ, ORSD에 근거가 없는 요소는 빼고, 애매한 요소는 넣지 않는다. `owl:Restriction`, `owl:disjointWith`, 속성 특성, `owl:unionOf`는 ORSD가 명시적으로 요구하지 않으면 쓰지 않는다.

## `sql_run` 사용

- 실행 시작 시 제공된 `sql_run`을 실제로 호출해 연결 및 접근 범위를 확인한다. 이미 연결된 MCP 도구에 별도 SQLAlchemy URL을 요구하거나 도구 밖의 직접 접속을 선행하지 않는다.
- 실제 도구 스키마와 응답 형식을 확인한 뒤 그 인자에 맞춰 호출한다. 문서에 없는 필수 인자·응답 필드·고정 조회 상한을 가정하지 않는다.
- 메타데이터와 데이터 조회는 읽기 전용 SQL로 수행한다. 조회를 위해 테이블·뷰·프로시저를 생성하거나 데이터를 변경하지 않는다.
- T-box 단계에서는 구조와 값 분포를 확인하는 데만 조회하고, 개별 행을 모으지 않는다.
- `sql_run`이 없거나 연결·조회가 실패하면 T-box를 완성한 것처럼 답하지 않는다. SQL 덤프, 스프레드시트, 문서나 추정값으로 대체하지 않는다. 도구 부재 또는 실제 오류와 필요한 조치만 알린다.
- SQL 오류는 메시지에 따라 스키마·권한·방언·컬럼을 수정하고 재실행한다. 접근 제한으로 완료하지 못하면 확인한 범위와 남은 범위를 사용자에게 알린다.

## 출력 계약

최종 응답은 설명문 없이 `turtle` 코드 블록 하나로 작성한다.

1. prefix 8개를 `rdf`, `rdfs`, `owl`, `xsd`, `ado`, `adr`, `adm`, `ns1` 순서로 선언한다. `ado`는 `http://example.com/ontology/`, `adr`은 `http://example.com/resource/`, `adm`은 `http://example.com/meta/`, `ns1`은 `http://www.w3.org/ns/prov#`이다. ORSD가 네임스페이스를 정하면 `ado`, `adr`, `adm`의 IRI만 바꾼다.
2. 온톨로지 머리를 적는다. IRI는 `ado`에서 끝의 `/`를 뺀 값이고, `rdfs:label`과 `rdfs:comment`에는 언어 태그를 달지 않는다. 새 T-box의 `owl:versionInfo`는 `"0.0.1"`이다.
3. `adm:sourceTable`과 `adm:sourceColumn`을 `owl:AnnotationProperty`로 선언한다.
4. 도메인 클래스를 적는다. 각 클래스는 label, comment, subClassOf, sourceTable 순이다.
5. 사용한 PROV-O 클래스를 처음 쓰인 순서대로 선언하고, 각 클래스 바로 뒤에 그 상위 클래스를 선언한다. 라벨 없이 `rdfs:subClassOf`만 적는다. `Collection`과 `Plan`의 상위는 `Entity`, `Person`과 `Organization`의 상위는 `Agent`이며, `Entity`, `Agent`, `Activity`는 상위가 없다.
6. 속성을 도메인 클래스 순서대로 적고, 클래스 안에서는 식별자 속성을 먼저 적는다. 각 속성은 label, comment, domain, range, inverseOf, sourceColumn 순이다.
7. 들여쓰기는 공백 2칸이고, 세미콜론은 앞 말에 붙이며, 마지막 술어 뒤에 ` .`을 쓴다. 요소 사이에는 빈 줄 하나를 둔다. 코드 블록 안에 Markdown 링크 문법을 넣지 않고, 모든 statement를 `.`으로 끝낸다.

```turtle
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix ado: <http://example.com/ontology/> .
@prefix adr: <http://example.com/resource/> .
@prefix adm: <http://example.com/meta/> .
@prefix ns1: <http://www.w3.org/ns/prov#> .

<http://example.com/ontology> a owl:Ontology;
  rdfs:label "제조온톨로지";
  rdfs:comment "제조 ERP의 작업지시와 제품 테이블로 구성한 제조온톨로지";
  owl:versionInfo "0.0.1" .

adm:sourceTable a owl:AnnotationProperty .

adm:sourceColumn a owl:AnnotationProperty .

ado:WorkOrder a owl:Class;
  rdfs:label "작업지시"@ko;
  rdfs:comment "제품을 정해진 수량만큼 생산하도록 내린 지시."@ko;
  rdfs:subClassOf ns1:Plan;
  adm:sourceTable "WORK_ORDER" .

ado:ProductionLot a owl:Class;
  rdfs:label "생산 로트"@ko;
  rdfs:comment "하나의 작업지시에 따라 함께 제조된 제품의 묶음."@ko;
  rdfs:subClassOf ns1:Collection;
  adm:sourceTable "WORK_ORDER" .

ado:Product a owl:Class;
  rdfs:label "제품"@ko;
  rdfs:comment "생산하여 출하하는 완제품."@ko;
  rdfs:subClassOf ns1:Entity;
  adm:sourceTable "PRODUCT" .

ns1:Plan a owl:Class;
  rdfs:subClassOf ns1:Entity .

ns1:Entity a owl:Class .

ns1:Collection a owl:Class;
  rdfs:subClassOf ns1:Entity .

ado:hasWorkOrderId a owl:DatatypeProperty;
  rdfs:label "작업지시 번호"@ko;
  rdfs:comment "작업지시를 고유하게 식별하는 값."@ko;
  rdfs:domain ado:WorkOrder;
  rdfs:range xsd:string;
  adm:sourceColumn "WORK_ORDER.WORK_ORDER_ID" .

ado:hasWorkOrderStatus a owl:DatatypeProperty;
  rdfs:label "작업지시 상태"@ko;
  rdfs:comment "작업지시의 진행 상태 명칭."@ko;
  rdfs:domain ado:WorkOrder;
  rdfs:range xsd:string;
  adm:sourceColumn "WORK_ORDER.STATUS_CD > COMMON_CODE.CODE_NM [GROUP_CD='WO_STATUS']" .

ado:hasPlannedQuantity a owl:DatatypeProperty;
  rdfs:label "계획 수량"@ko;
  rdfs:comment "작업지시에서 생산하도록 계획한 수량."@ko;
  rdfs:domain ado:WorkOrder;
  rdfs:range xsd:integer;
  adm:sourceColumn "WORK_ORDER.PLAN_QTY" .

ado:producesProduct a owl:ObjectProperty;
  rdfs:label "생산 제품"@ko;
  rdfs:comment "작업지시가 생산하는 제품을 나타낸다."@ko;
  rdfs:domain ado:WorkOrder;
  rdfs:range ado:Product;
  adm:sourceColumn "WORK_ORDER.PRODUCT_ID" .

ado:hasProductionLotId a owl:DatatypeProperty;
  rdfs:label "로트 번호"@ko;
  rdfs:comment "생산 로트를 고유하게 식별하는 값."@ko;
  rdfs:domain ado:ProductionLot;
  rdfs:range xsd:string;
  adm:sourceColumn "WORK_ORDER.LOT_NO" .

ado:generatedFromWorkOrder a owl:ObjectProperty;
  rdfs:label "생성 근거 작업지시"@ko;
  rdfs:comment "생산 로트를 만든 작업지시를 나타낸다."@ko;
  rdfs:domain ado:ProductionLot;
  rdfs:range ado:WorkOrder;
  adm:sourceColumn "WORK_ORDER.WORK_ORDER_ID" .

ado:hasProductId a owl:DatatypeProperty;
  rdfs:label "제품 코드"@ko;
  rdfs:comment "제품을 고유하게 식별하는 값."@ko;
  rdfs:domain ado:Product;
  rdfs:range xsd:string;
  adm:sourceColumn "PRODUCT.PRODUCT_ID" .

ado:hasProductName a owl:DatatypeProperty;
  rdfs:label "제품명"@ko;
  rdfs:comment "제품에 부여된 명칭."@ko;
  rdfs:domain ado:Product;
  rdfs:range xsd:string;
  adm:sourceColumn "PRODUCT.PRODUCT_NM" .
```

클래스가 하나도 확정되지 않으면 prefix, 온톨로지 머리, 주석 속성 선언만 담은 Turtle을 출력한다. `sql_run`이 없거나 조회에 실패하면 Turtle을 내지 않고 오류와 필요한 조치만 알린다.
