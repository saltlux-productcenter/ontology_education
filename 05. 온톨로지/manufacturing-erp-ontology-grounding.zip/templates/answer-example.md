# 출력 예시

이 파일은 모드 A 와 모드 B 의 출력 예시다. IRI 는 이 온톨로지의 `ado:`(`http://example.com/ontology/`) · `adr:`(`http://example.com/resource/`) IRI 이고, KG 쪽 값은 원본 TTL 의 instance 값이며, 모드 B 의 문서 본문은 예시 입력이다. 도구 이름은 text2sparql v2 이름이다. 결과에 옮겨 쓰지 않는다.

## 1. 모드 A 예시

질문: 「생산 로트 LOT-TH100-260929-03 의 검사에서 불합격한 장치와 측정값은?」

질문 분석: 답 모양은 목록, 대상은 「생산 로트 LOT-TH100-260929-03」, 조건은 판정 불합격이며 기간 · 단위는 없다.

확정 어휘 표

| 용어 | IRI | 출처 |
|---|---|---|
| 생산 로트 | `ado:ProductionLot` | schema card 3절 |
| 검사 결과 | `ado:InspectionResult` | schema card 3절 |
| 측정값 | `ado:hasMeasuredValue` | schema card 5절 |
| 판정 | `ado:hasInspectionResult` | schema card 5절 |

entity 표

| 언급 | IRI | 일치 방식 | 후보 수 |
|---|---|---|---|
| LOT-TH100-260929-03 | `adr:ProductionLot_LOT-TH100-260929-03` | exact | 1 |

조회 기록

| 조회 번호 | 도구 | 인자 요약 | status | 행 수 | 핵심 행 |
|---|---|---|---|---|---|
| Q01 | `kg_search_entities` | name 「LOT-TH100-260929-03」, class_iri `ado:ProductionLot` | ok | 1 | `adr:ProductionLot_LOT-TH100-260929-03`(exact) |
| Q02 | `sparql_run` | T03, production_lot `adr:ProductionLot_LOT-TH100-260929-03` | ok | 2 | TH100-260929-0022: `?measured` 25.8, `?deviation` 0.8, `?result` 불합격 / TH100-260929-0076: `?measured` 25.9, `?deviation` 0.9, `?result` 불합격 |

최종 출력

```
[답] 생산 로트 LOT-TH100-260929-03 의 검사 QC-260929-004 에서 온도 오차(QC-T01) 판정이 불합격인 장치는 TH100-260929-0022(측정값 25.8)와 TH100-260929-0076(측정값 25.9) 2대다. 기준값 25.0 과의 차이 0.8 · 0.9 가 허용 오차 0.5 를 넘는다.
[근거] Q02(T03) 2행: ?deviceId, ?measured, ?deviation, ?withinTolerance = false, ?result = "불합격"
[범위] repository {{REPOSITORY_ID}}, 추론 미포함(includeInferred=false), 온톨로지에 기록된 검사 결과 기준, 이번 실행 기준
[미확인] 없음
```

```json
{"schema_version": "0.1",
 "mode": "A",
 "question": "생산 로트 LOT-TH100-260929-03 의 검사에서 불합격한 장치와 측정값은?",
 "vocabulary": [
   {"term": "생산 로트", "iri": "http://example.com/ontology/ProductionLot", "source": "schema_card"},
   {"term": "검사 결과", "iri": "http://example.com/ontology/InspectionResult", "source": "schema_card"},
   {"term": "측정값", "iri": "http://example.com/ontology/hasMeasuredValue", "source": "schema_card"},
   {"term": "판정", "iri": "http://example.com/ontology/hasInspectionResult", "source": "schema_card"}],
 "entities": [
   {"mention": "LOT-TH100-260929-03", "iri": "http://example.com/resource/ProductionLot_LOT-TH100-260929-03", "match": "exact", "candidates": []}],
 "queries": [
   {"id": "Q01", "tool": "kg_search_entities", "template_id": "", "sparql": "",
    "args": {"name": "LOT-TH100-260929-03", "class_iri": "http://example.com/ontology/ProductionLot"},
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 1, "inferred": null, "repair_count": 0},
   {"id": "Q02", "tool": "sparql_run", "template_id": "T03", "sparql": "",
    "args": {"production_lot": "<http://example.com/resource/ProductionLot_LOT-TH100-260929-03>"},
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 2, "inferred": false, "repair_count": 0}],
 "answer": "생산 로트 LOT-TH100-260929-03 의 검사 QC-260929-004 에서 온도 오차 판정이 불합격인 장치는 TH100-260929-0022(측정값 25.8)와 TH100-260929-0076(측정값 25.9) 2대다.",
 "evidence": [{"query_ref": "Q02", "rows": [
   {"inspectionId": "QC-260929-004", "deviceId": "TH100-260929-0022", "itemId": "QC-T01", "itemName": "온도 오차", "measured": "25.8", "reference": "25.0", "tolerance": "0.5", "deviation": "0.8", "withinTolerance": "false", "result": "불합격"},
   {"inspectionId": "QC-260929-004", "deviceId": "TH100-260929-0076", "itemId": "QC-T01", "itemName": "온도 오차", "measured": "25.9", "reference": "25.0", "tolerance": "0.5", "deviation": "0.9", "withinTolerance": "false", "result": "불합격"}],
   "triples": []}],
 "unresolved": [],
 "warnings": []}
```

## 2. 모드 B 예시

입력: 「WO-260924-002 생산 완료 보고」(작성일 2026-09-26)를 붙여 넣고 온톨로지 근거로 타당성을 검증해 달라는 요청. 문서 본문은 아래 세 문장이다.

```
작업지시 WO-260924-002 는 생산 수량 200대로 완료되었다.
시리얼 TH100-260924-0027 장치는 재작업 이력이 없다. 이 작업지시에는 품질 보류가 없다.
```

추출한 주장

| claim_id | attribute | value · unit | period | claim_type | quote |
|---|---|---|---|---|---|
| C01 | 생산 수량 | 200 · 대 | - | fact | WO-260924-002 는 생산 수량 200대 |
| C02 | 작업 상태 | 완료 | - | fact | 200대로 완료되었다 |
| C03 | 재작업 이력 | 없음 | - | absence | TH100-260924-0027 장치는 재작업 이력이 없다 |
| C04 | 품질 보류 | 없음 | - | absence | 이 작업지시에는 품질 보류가 없다 |

확정 어휘 표

| 용어 | IRI | 출처 |
|---|---|---|
| 작업지시 | `ado:WorkOrder` | schema card 3절 |
| 생산 수량 | `ado:hasProducedQuantity` | schema card 5절 |
| 작업 상태 | `ado:hasWorkOrderStatus` | schema card 5절 |
| 실제 완료일시 | `ado:completedAt` | schema card 5절 |
| 장치 | `ado:Device` | schema card 3절 |
| 재작업 대상 장치 | `ado:reworkedDevice` | schema card 4절 |
| 보류 작업지시 | `ado:heldWorkOrder` | schema card 4절 |

조회 기록

| 조회 번호 | 도구 | 인자 요약 | status | 행 수 | 핵심 행 |
|---|---|---|---|---|---|
| Q01 | `kg_search_entities` | name 「WO-260924-002」, class_iri `ado:WorkOrder` | ok | 1 | `adr:WorkOrder_WO-260924-002`(exact) |
| Q02 | `sparql_run` | T01, work_order `adr:WorkOrder_WO-260924-002` | ok | 11 | `ado:hasProducedQuantity` "200", `ado:hasWorkOrderStatus` "완료", `ado:completedAt` 행 없음 |
| Q03 | `kg_search_entities` | name 「TH100-260924-0027」, class_iri `ado:Device` | ok | 1 | `adr:Device_TH100-260924-0027`(exact) |
| Q04 | `sparql_run` | T06, device `adr:Device_TH100-260924-0027` | ok | 1 | `?reworkId` RW-260925-001, `?initialInspectionId` QC-260924-002, `?reinspectionId` QC-260925-003 |
| Q05 | `sparql_run` | T09, target `adr:WorkOrder_WO-260924-002` | ok | - | boolean false |

판정 기록

```
[판정] C01 | supported | R04 | 근거 Q02 | 문서 200대, KG ado:hasProducedQuantity 200
[판정] C02 | anomaly | R01 | 근거 Q02 | KG 작업 상태 "완료", ado:completedAt 행 없음
[판정] C03 | refuted | R10 | 근거 Q04 | 문서 재작업 이력 없음, KG 재작업 RW-260925-001 1건
[판정] C04 | not_in_kg | R12 | 근거 Q05 | ASK false
```

최종 출력

```
[판정 분포] 주장 4건: supported 1, refuted 1, anomaly 1, granularity 0, temporal 0, not_in_kg 1, blocked 0
[불일치] C03(refuted, R10): 문서 「재작업 이력 없음」, KG 재작업 RW-260925-001(최초 검사 QC-260924-002, 재검사 QC-260925-003) / C02(anomaly, R01): KG 작업 상태 "완료"이나 ado:completedAt 없음
[미확인] C04: not_in_kg, Q05 ASK false
[검토 필요] 없음
```

```json
{"schema_version": "0.1",
 "mode": "B",
 "document": {"name": "WO-260924-002 생산 완료 보고", "date": "2026-09-26"},
 "subject": {"mention": "작업지시 WO-260924-002", "iri": "http://example.com/resource/WorkOrder_WO-260924-002", "match": "exact"},
 "claims": [
   {"claim_id": "C01", "subject_mention": "작업지시 WO-260924-002", "attribute": "생산 수량", "value": "200", "unit": "대",
    "period": {"start": "", "end": ""}, "quote": "WO-260924-002 는 생산 수량 200대", "location": "1문장", "claim_type": "fact"},
   {"claim_id": "C02", "subject_mention": "작업지시 WO-260924-002", "attribute": "작업 상태", "value": "완료", "unit": "",
    "period": {"start": "", "end": ""}, "quote": "200대로 완료되었다", "location": "1문장", "claim_type": "fact"},
   {"claim_id": "C03", "subject_mention": "시리얼 TH100-260924-0027 장치", "attribute": "재작업 이력", "value": "없음", "unit": "",
    "period": {"start": "", "end": ""}, "quote": "TH100-260924-0027 장치는 재작업 이력이 없다", "location": "2문장", "claim_type": "absence"},
   {"claim_id": "C04", "subject_mention": "이 작업지시", "attribute": "품질 보류", "value": "없음", "unit": "",
    "period": {"start": "", "end": ""}, "quote": "이 작업지시에는 품질 보류가 없다", "location": "3문장", "claim_type": "absence"}],
 "queries": [
   {"id": "Q01", "tool": "kg_search_entities", "template_id": "", "sparql": "",
    "args": {"name": "WO-260924-002", "class_iri": "http://example.com/ontology/WorkOrder"}, "claim_ids": [],
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 1, "inferred": null, "repair_count": 0},
   {"id": "Q02", "tool": "sparql_run", "template_id": "T01", "sparql": "",
    "args": {"work_order": "<http://example.com/resource/WorkOrder_WO-260924-002>"}, "claim_ids": ["C01", "C02"],
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 11, "inferred": false, "repair_count": 0},
   {"id": "Q03", "tool": "kg_search_entities", "template_id": "", "sparql": "",
    "args": {"name": "TH100-260924-0027", "class_iri": "http://example.com/ontology/Device"}, "claim_ids": ["C03"],
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 1, "inferred": null, "repair_count": 0},
   {"id": "Q04", "tool": "sparql_run", "template_id": "T06", "sparql": "",
    "args": {"device": "<http://example.com/resource/Device_TH100-260924-0027>"}, "claim_ids": ["C03"],
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 1, "inferred": false, "repair_count": 0},
   {"id": "Q05", "tool": "sparql_run", "template_id": "T09", "sparql": "",
    "args": {"target": "<http://example.com/resource/WorkOrder_WO-260924-002>"}, "claim_ids": ["C04"],
    "repository": "{{REPOSITORY_ID}}", "status": "ok", "row_count": 0, "inferred": false, "repair_count": 0}],
 "verdicts": [
   {"claim_id": "C01", "category": "supported", "rule_id": "R04", "evidence_refs": ["Q02"],
    "explanation": "문서 200대와 KG ado:hasProducedQuantity 200 의 차이 0 이 허용 오차 0 이하다. R01~R03 의 조건에는 해당하지 않는다."},
   {"claim_id": "C02", "category": "anomaly", "rule_id": "R01", "evidence_refs": ["Q02"],
    "explanation": "KG 작업 상태는 완료이나 실제 완료일시 ado:completedAt 이 기록되어 있지 않아 KG 기록이 서로 맞지 않는다."},
   {"claim_id": "C03", "category": "refuted", "rule_id": "R10", "evidence_refs": ["Q04"],
    "explanation": "KG 에 이 장치를 대상으로 한 재작업 RW-260925-001 이 있고, 최초 검사 QC-260924-002 와 재검사 QC-260925-003 이 이를 참조한다."},
   {"claim_id": "C04", "category": "not_in_kg", "rule_id": "R12", "evidence_refs": ["Q05"],
    "explanation": "ASK 결과가 false 다. 품질 보류는 빠짐없이 기록하는 대상으로 정해지지 않아 KG 부재를 사실 부재로 보지 않는다."}],
 "unresolved": [],
 "hitl_queue": [],
 "metrics": {"judged": [4, 4], "evidence_backed": [4, 4], "rule_backed": [4, 4]}}
```
