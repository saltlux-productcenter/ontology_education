> 1/2 분할 · 다음 파일: schema-card-2.md

# schema card

> 1~7절은 `scripts/build_schema_card.py` 가 생성했다. 8~9절만 작성자가 고치고, 1~7절은 script 를 다시 실행해 갱신한다.

## 1. 온톨로지 개요

| 항목 | 값 |
|---|---|
| 이름 | 제조 ERP 온톨로지 |
| repository | {{REPOSITORY_ID}} |
| base IRI | http://example.com/ontology/ |
| label 언어 우선순위 | ko, en 순 |
| 추론 설정 | includeInferred=false |
| 생성 방식 | build_schema_card.py 자동 생성(2026-09-30). source: 파일 manufacturing_erp_ontology.ttl (rdflib, 추론 없음). 옵션: lang ko,en · limit 500 · enum-max 20 · instance 수 집계 켬 |

## 2. prefix

| prefix | namespace |
|---|---|
| ado: | http://example.com/ontology/ |
| prov: | http://www.w3.org/ns/prov# |
| rdf: | http://www.w3.org/1999/02/22-rdf-syntax-ns# |
| rdfs: | http://www.w3.org/2000/01/rdf-schema# |
| xsd: | http://www.w3.org/2001/XMLSchema# |

## 3. class

| IRI(축약) | label | 상위 class | instance 수 | 설명 |
|---|---|---|---|---|
| ado:Bom | BOM | prov:Entity | 1 | 제품 1대당 구성품과 기준 소요량을 정의한 자재 구성 명세서이다. |
| ado:Department | 조직 | prov:Organization | 3 | 회사 내부의 부서 또는 팀 단위 조직이다. |
| ado:Device | 불합격 장치(시리얼) | prov:Entity | 6 | 시리얼번호가 식별하는 완제품 개별 장치이다. |
| ado:Employee | 사람 | prov:Person | 5 | 작업지시 수행, 검사, 재작업을 담당하는 사람이다. |
| ado:Inspection | 검사 기록 | prov:Activity | 4 | 검사번호, 대상 생산 로트, 검사 일시, 검사자, 사용 장비, 기준값, 측정값 및 판정을 기재한 출하 검사 기록이다. |
| ado:InspectionItem | 검사항목·기준 | prov:Entity | 2 | 출하 검사에 적용하는 검사항목 코드와 시험 조건·합격 기준을 정의한다. |
| ado:InspectionResult | 검사 결과 | prov:Activity | 2 | 검사 기록에서 검사항목과 대상 장치를 기준으로 내린 개별 판정 결과이다. |
| ado:Machine | 설비 | prov:Entity | 6 | 제조 작업에 사용되는 기계 또는 생산 설비이다. |
| ado:Material | 자재(품목) | prov:Entity | 6 | 제품 제조에 투입되는 품목으로, 자재코드가 부품의 종류를 식별한다. |
| ado:MaterialConsumption | 자재 투입 기록 | prov:Activity | 3 | 작업지시 수행을 위해 자재 입고 로트를 실제로 투입한 기록이다. |
| ado:MaterialLot | 자재 입고 로트 | prov:Collection | 7 | 입고 로트번호가 실제 사용한 자재 묶음을 식별하는 자재 묶음이다. |
| ado:Product | 제품 | prov:Entity | 1 | 실내 온도와 상대습도를 측정하여 Wi-Fi로 전송하는 USB 전원 방식의 IoT 센서로, 완제품에는 고유 시리얼번호가 부여된다. |
| ado:ProductSpecification | 제품사양서 개정 | prov:Entity | 1 | TH-100의 조립, 펌웨어 설치, 출하 검사 및 포장에 적용하는 사양 문서와 그 개정이다. |
| ado:ProductionLot | 생산 로트 | prov:Collection | 3 | 동일한 생산 공정이나 조건에 따라 함께 제조된 제품의 묶음이다. |
| ado:QualityHold | 품질 보류 | prov:Activity | 1 | 품질관리팀이 추가 투입과 출하를 보류한 기록이다. |
| ado:Rework | 재작업 기록 | prov:Activity | 1 | 최초 불합격 장치에 대해 수행한 재작업의 조치 내용과 담당자를 기록한 것이다. |
| ado:Supplier | 공급업체 | prov:Organization | 4 | 자재를 공급하는 승인 공급업체이다. |
| ado:WorkOrder | 작업지시 | prov:Plan | 3 | 개별 생산분의 작업 내용, 수량, 적용 사양서·BOM 개정과 계획·실적 수량을 지시하는 기록이다. |
| prov:Activity | Activity |  | 0 |  |
| prov:Agent | Agent |  | 0 |  |
| prov:Collection | Collection | prov:Entity | 0 |  |
| prov:Entity | Entity |  | 0 |  |
| prov:Organization | Organization | prov:Agent | 0 |  |
| prov:Person | Person | prov:Agent | 0 |  |
| prov:Plan | Plan | prov:Entity | 0 |  |

## 4. object property

| IRI | label | domain | range | 설명 |
|---|---|---|---|---|
| ado:appliesBom | 적용 BOM 개정 | ado:WorkOrder | ado:Bom | 작업지시에 적용된 BOM 개정을 나타낸다. |
| ado:appliesSpecification | 적용 사양서 개정 | ado:WorkOrder | ado:ProductSpecification | 작업지시에 적용된 제품사양서 개정을 나타낸다. |
| ado:definesInspectionItem | 검사항목 정의 | ado:ProductSpecification | ado:InspectionItem | 제품사양서가 정의하는 검사항목을 나타낸다. |
| ado:forMaterial | 입고 자재 | ado:MaterialLot | ado:Material | 자재 입고 로트가 해당하는 자재 품목을 나타낸다. |
| ado:forProduct | 생산 대상 제품 | ado:WorkOrder | ado:Product | 작업지시가 생산하는 제품을 나타낸다. |
| ado:forProductionLot | 검사 대상 로트 | ado:Inspection | ado:ProductionLot | 검사 기록의 대상 생산 로트를 나타낸다. |
| ado:forWorkOrder | 검사 대상 작업지시 | ado:Inspection | ado:WorkOrder | 검사 기록이 속한 작업지시를 나타낸다. |
| ado:hasInspectionRecord | 해당 검사 기록 | ado:ProductionLot | ado:Inspection | 생산 로트에 수행된 검사 기록을 나타낸다. |
| ado:heldMaterialLot | 보류 입고 로트 | ado:QualityHold | ado:MaterialLot | 품질 보류의 대상 자재 입고 로트를 나타낸다. |
| ado:heldProductionLot | 보류 생산 로트 | ado:QualityHold | ado:ProductionLot | 품질 보류의 대상 생산 로트를 나타낸다. |
| ado:heldWorkOrder | 보류 작업지시 | ado:QualityHold | ado:WorkOrder | 품질 보류가 영향을 미치는 작업지시를 나타낸다. |
| ado:inProductionLot | 소속 생산 로트 | ado:Device | ado:ProductionLot | 장치가 속한 생산 로트를 나타낸다. |
| ado:listsMaterial | BOM 구성품 | ado:Bom | ado:Material | BOM에 포함된 구성품 자재를 나타낸다. |
| ado:listsProduct | BOM 대상 제품 | ado:Bom | ado:Product | BOM이 구성을 정의하는 제품을 나타낸다. |
| ado:ofDevice | 검사 결과 대상 장치 | ado:InspectionResult | ado:Device | 검사 결과가 판정한 대상 장치를 나타낸다. |
| ado:ofInspection | 검사 결과 대상 검사 | ado:InspectionResult | ado:Inspection | 검사 결과가 속한 검사 기록을 나타낸다. |
| ado:ofInspectionItem | 검사 결과 대상 항목 | ado:InspectionResult | ado:InspectionItem | 검사 결과가 적용된 검사항목을 나타낸다. |
| ado:ofMaterialLot | 투입 입고 로트 | ado:MaterialConsumption | ado:MaterialLot | 자재 투입 기록이 투입한 자재 입고 로트를 나타낸다. |
| ado:ofWorkOrder | 투입 작업지시 | ado:MaterialConsumption | ado:WorkOrder | 자재 투입이 수행된 작업지시를 나타낸다. |
| ado:performedBy | 담당자 | ado:WorkOrder | ado:Employee | 작업지시를 수행한 담당자를 나타낸다. |
| ado:performedOnMachine | 사용 설비 | ado:WorkOrder | ado:Machine | 작업지시 수행에 사용된 설비를 나타낸다. |
| ado:producesLot | 생산 로트 지정 | ado:WorkOrder | ado:ProductionLot | 작업지시가 생산하는 생산 로트를 나타낸다. |
| ado:referencesInitialInspection | 재작업 참조 검사 | ado:Rework | ado:Inspection | 재작업의 근거가 된 최초 검사 기록을 나타낸다. |
| ado:referencesInspection | 참조 검사번호 | ado:Inspection | ado:Inspection | 재검사 기록이 참조하는 최초 검사 기록을 나타낸다. |
| ado:referencesRework | 참조 조치기록 | ado:Inspection | ado:Rework | 재검사 기록이 참조하는 재작업 기록을 나타낸다. |
| ado:reworkedDevice | 재작업 대상 장치 | ado:Rework | ado:Device | 재작업이 수행된 대상 장치를 나타낸다. |
| ado:specifiedForProduct | 사양 대상 제품 | ado:ProductSpecification | ado:Product | 제품사양서가 적용되는 제품을 나타낸다. |
| ado:suppliedBySupplier | 승인 공급업체 | ado:Material | ado:Supplier | 자재에 승인된 공급업체를 나타낸다. |
| ado:usedInConsumption | 투입 기록 연결 | ado:MaterialLot | ado:MaterialConsumption | 자재 입고 로트가 실제로 투입된 자재 투입 기록을 나타낸다. |

## 5. data property

| IRI | label | domain | datatype | 설명 |
|---|---|---|---|---|
| ado:completedAt | 실제 완료일시 | ado:WorkOrder | xsd:dateTime | 작업지시의 실제 완료일시. |
| ado:hasBomId | BOM 번호 | ado:Bom | xsd:string | BOM을 고유하게 식별하는 값. |
| ado:hasBomRevision | BOM 개정 | ado:Bom | xsd:string | BOM의 개정번호. |
| ado:hasConsumedQuantity | 실제 투입량 | ado:MaterialConsumption | xsd:integer | 자재 투입 기록의 실제 투입 수량. |
| ado:hasDepartmentId | 조직 코드 | ado:Department | xsd:string | 조직을 고유하게 식별하는 값. |
| ado:hasDepartmentName | 조직명 | ado:Department | xsd:string | 조직에 부여된 명칭. |
| ado:hasDeviceId | 시리얼번호 | ado:Device | xsd:string | 장치를 고유하게 식별하는 값, 시리얼번호. |
| ado:hasEmployeeId | 사번 | ado:Employee | xsd:string | 사람을 고유하게 식별하는 값. |
| ado:hasEmployeeName | 성명 | ado:Employee | xsd:string | 사람에 부여된 명칭. |
| ado:hasHeldQuantity | 보류 대상 수량 | ado:QualityHold | xsd:integer | 품질 보류의 대상 수량. |
| ado:hasHoldReason | 보류 사유 | ado:QualityHold | xsd:string | 품질 보류의 사유로, 미확정 원인은 단정하지 않은 내용. |
| ado:hasHoldStatus | 보류 상태 | ado:QualityHold | xsd:string | 품질 보류 기록의 상태. |
| ado:hasInspectionFailedQuantity | 검사 불합격 수량 | ado:WorkOrder | xsd:integer | 기준일시 현재 검사에서 불합격한 수량. |
| ado:hasInspectionId | 검사번호 | ado:Inspection | xsd:string | 검사 기록을 고유하게 식별하는 값. |
| ado:hasInspectionItemCriteria | 시험 조건/합격 기준 | ado:InspectionItem | xsd:string | 검사항목의 시험 조건과 합격 기준. |
| ado:hasInspectionItemId | 검사항목 코드 | ado:InspectionItem | xsd:string | 검사항목을 고유하게 식별하는 값. |
| ado:hasInspectionItemName | 검사항목명 | ado:InspectionItem | xsd:string | 검사항목에 부여된 명칭. |
| ado:hasInspectionPassedQuantity | 검사 합격 수량 | ado:WorkOrder | xsd:integer | 기준일시 현재 검사에 합격한 수량. |
| ado:hasInspectionResult | 판정 | ado:InspectionResult | xsd:string | 검사 결과의 판정, 합격 또는 불합격. |
| ado:hasInspectionResultId | 검사 결과 식별자 | ado:InspectionResult | xsd:string | 검사 결과를 고유하게 식별하는 값. |
| ado:hasMachineId | 설비 코드 | ado:Machine | xsd:string | 설비를 고유하게 식별하는 값. |
| ado:hasMachineName | 설비명 | ado:Machine | xsd:string | 설비에 부여된 명칭. |
| ado:hasMaterialConsumptionId | 투입 기록번호 | ado:MaterialConsumption | xsd:string | 자재 투입 기록을 고유하게 식별하는 값. |
| ado:hasMaterialId | 자재코드 | ado:Material | xsd:string | 자재를 고유하게 식별하는 값. |
| ado:hasMaterialLotId | 입고 로트번호 | ado:MaterialLot | xsd:string | 자재 입고 로트를 고유하게 식별하는 값. |
| ado:hasMaterialLotStatus | 입고 로트 상태 | ado:MaterialLot | xsd:string | 자재 입고 로트의 상태, 사용 보류 포함. |
| ado:hasMaterialName | 자재명/규격 | ado:Material | xsd:string | 자재에 부여된 명칭과 규격. |
| ado:hasMaterialType | 품목 유형 | ado:Material | xsd:string | 자재의 품목 유형, 반제품·부품·부자재. |
| ado:hasMeasuredValue | 측정값 | ado:InspectionResult | xsd:decimal | 검사 결과에서 장치를 측정해 얻은 값. |
| ado:hasPlannedQuantity | 계획(지시) 수량 | ado:WorkOrder | xsd:integer | 작업지시의 계획 수량, 지시 수량. |
| ado:hasProducedQuantity | 생산 수량 | ado:WorkOrder | xsd:integer | 기준일시 현재 작업지시의 생산 수량. |
| ado:hasProductId | 제품코드 | ado:Product | xsd:string | 제품을 고유하게 식별하는 값. |
| ado:hasProductName | 모델명 | ado:Product | xsd:string | 제품에 부여된 명칭. |
| ado:hasProductSpecificationId | 사양서 번호 | ado:ProductSpecification | xsd:string | 제품사양서를 고유하게 식별하는 값. |
| ado:hasProductSpecificationRevision | 개정번호 | ado:ProductSpecification | xsd:string | 제품사양서의 개정번호. |
| ado:hasProductionLotId | 생산 로트번호 | ado:ProductionLot | xsd:string | 생산 로트를 고유하게 식별하는 값. |
| ado:hasQualityHoldId | 보류 기록번호 | ado:QualityHold | xsd:string | 품질 보류 기록을 고유하게 식별하는 값. |
| ado:hasQuantityPerUnit | 기준 소요량 | ado:Bom | xsd:decimal | 제품 1대당 필요한 구성품의 기준 소요량. |
| ado:hasReceivedQuantity | 입고량 | ado:MaterialLot | xsd:integer | 자재 입고 로트의 입고 수량. |
| ado:hasReferenceValue | 기준값 | ado:InspectionItem | xsd:decimal | 검사항목 판정에 사용하는 기준점 값. |
| ado:hasReworkId | 조치기록번호 | ado:Rework | xsd:string | 재작업 기록을 고유하게 식별하는 값. |
| ado:hasShipmentApprovedQuantity | 출하 승인 수량 | ado:WorkOrder | xsd:integer | 출하 승인을 받은 수량으로, 품질 보류 중인 검사 합격품은 포함하지 않는다. |
| ado:hasSupplierId | 공급업체 코드 | ado:Supplier | xsd:string | 공급업체를 고유하게 식별하는 값. |
| ado:hasSupplierName | 공급업체명 | ado:Supplier | xsd:string | 공급업체에 부여된 명칭. |
| ado:hasTolerance | 허용 오차 | ado:InspectionItem | xsd:decimal | 검사항목 판정에서 허용되는 오차. |
| ado:hasUnit | 단위 | ado:Bom | xsd:string | 기준 소요량의 단위. |
| ado:hasUnproducedQuantity | 미생산 수량 | ado:WorkOrder | xsd:integer | 지시 수량에서 생산 수량을 제외한 미생산 수량. |
| ado:hasWorkOrderId | 작업지시번호 | ado:WorkOrder | xsd:string | 작업지시를 고유하게 식별하는 값. |
| ado:hasWorkOrderReferenceAt | 기준일시 | ado:WorkOrder | xsd:dateTime | 작업지시의 현재 상태와 수량이 적용되는 기준일시. |
| ado:hasWorkOrderStatus | 작업 상태 | ado:WorkOrder | xsd:string | 기준일시 현재 작업지시의 상태. |
| ado:inspectedAt | 검사 일시 | ado:Inspection | xsd:dateTime | 검사 기록의 수행 일시. |
| ado:plannedCompletionAt | 예정 완료일시 | ado:WorkOrder | xsd:dateTime | 작업지시의 예정 완료일시. |

## 6. class 관계

> object property 의 domain → range 에서 유도했다. owl:unionOf 는 구성 class 로 펼쳤고, domain 이나 range 가 없는 property 는 제외했다.

| source | predicate | target |
|---|---|---|
| ado:Bom | ado:listsMaterial | ado:Material |
| ado:Bom | ado:listsProduct | ado:Product |
| ado:Device | ado:inProductionLot | ado:ProductionLot |
| ado:Inspection | ado:forProductionLot | ado:ProductionLot |
| ado:Inspection | ado:forWorkOrder | ado:WorkOrder |
| ado:Inspection | ado:referencesInspection | ado:Inspection |
| ado:Inspection | ado:referencesRework | ado:Rework |
| ado:InspectionResult | ado:ofDevice | ado:Device |
| ado:InspectionResult | ado:ofInspection | ado:Inspection |
| ado:InspectionResult | ado:ofInspectionItem | ado:InspectionItem |
| ado:Material | ado:suppliedBySupplier | ado:Supplier |
| ado:MaterialConsumption | ado:ofMaterialLot | ado:MaterialLot |
| ado:MaterialConsumption | ado:ofWorkOrder | ado:WorkOrder |
| ado:MaterialLot | ado:forMaterial | ado:Material |
| ado:MaterialLot | ado:usedInConsumption | ado:MaterialConsumption |
| ado:ProductSpecification | ado:definesInspectionItem | ado:InspectionItem |
| ado:ProductSpecification | ado:specifiedForProduct | ado:Product |
| ado:ProductionLot | ado:hasInspectionRecord | ado:Inspection |
| ado:QualityHold | ado:heldMaterialLot | ado:MaterialLot |
| ado:QualityHold | ado:heldProductionLot | ado:ProductionLot |
| ado:QualityHold | ado:heldWorkOrder | ado:WorkOrder |
| ado:Rework | ado:referencesInitialInspection | ado:Inspection |
| ado:Rework | ado:reworkedDevice | ado:Device |
| ado:WorkOrder | ado:appliesBom | ado:Bom |
| ado:WorkOrder | ado:appliesSpecification | ado:ProductSpecification |
| ado:WorkOrder | ado:forProduct | ado:Product |
| ado:WorkOrder | ado:performedBy | ado:Employee |
