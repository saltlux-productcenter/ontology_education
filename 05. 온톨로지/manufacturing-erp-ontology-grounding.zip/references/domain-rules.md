# 도메인 규칙

이 문서는 대상 온톨로지에 따라 달라지는 설정값, entity 자동 선택 규칙, 판정 규칙 표, 임계값, 안내 문구를 모은 설정 파일이다. skill 의 다른 파일은 이 값을 참조한다.

## Contents

1. 온톨로지 기본 정보
2. label 언어와 추론 설정
3. entity 자동 선택 규칙
4. 문서 시점 필드
5. 판정 규칙 표
6. 임계값
7. 범위 밖 안내와 금지 어휘

## 1. 온톨로지 기본 정보

온톨로지 기본 정보는 답변의 `[범위]` 줄과 도구 인자에 쓰는 식별 정보다.

- 온톨로지 이름: 제조 ERP 온톨로지

- repository: `{{REPOSITORY_ID}}`

> 작성 요령: 도구 repository 인자에 넣을 ID 를 적는다. 도구 설정의 기본 repository 를 쓰면 「도구 기본값」으로 적는다. 예: `example-repo`

- base IRI: `http://example.com/ontology/`(class · property, prefix `ado:`). instance IRI 는 `http://example.com/resource/` 로 시작하며 prefix `adr:` 로 적는다. schema card 2절에는 `adr:` 가 없으므로 SPARQL 에 쓰려면 `PREFIX adr: <http://example.com/resource/>` 를 선언하거나 꺾쇠로 감싼 절대 IRI 를 쓴다.

## 2. label 언어와 추론 설정

label 언어와 추론 설정은 결과 표시와 질의 실행에 공통으로 적용하는 값이다.

- label 언어 우선순위: ko, en. 이 온톨로지의 `rdfs:label` 은 모두 `@ko` 다.

- 추론 기본값: `includeInferred=false`. 이 값은 도구 환경변수 `SOR_INCLUDE_INFERRED` 가 정하며 도구 초기값은 true 이므로 배치 때 false 로 맞춘다. `owl:inverseOf` 로 선언된 `ado:forProductionLot` · `ado:hasInspectionRecord` 는 추론 없이 한쪽만 적재될 수 있으므로 template 은 두 방향을 함께 본다.

## 3. entity 자동 선택 규칙

entity 자동 선택 규칙은 entity 후보가 2건 이상일 때 되묻지 않고 고를 수 있는 조건이다.

- 자동 선택 조건: 검색어가 식별자 property(schema card 5절에서 이름이 `Id` 로 끝나는 data property, 예: `ado:hasWorkOrderId` · `ado:hasProductionLotId` · `ado:hasMaterialLotId` · `ado:hasDeviceId` · `ado:hasInspectionId`) 값이고, `kg_search_entities` 결과에서 match 가 exact 이며 types 에 대상 class 가 있는 후보가 1건인 경우.
- 조건에 맞으면 그 후보를 고르고 entity 표의 일치 방식을 `auto_rule` 로 적는다. 사람 · 설비 · 공급업체 이름처럼 식별자가 아닌 검색어이거나 exact 후보가 2건 이상이면 되묻는다.

## 4. 문서 시점 필드

문서 시점 필드는 모드 B 에서 문서의 기준 시점을 읽는 자리와, 비교할 KG 유효기간 property 의 짝이다.

- 문서의 작성일 또는 검사일시(문서 머리 → 본문 표 순서로 찾는다) ↔ `ado:hasWorkOrderReferenceAt`(작업지시 수량 · 상태의 기준일시) · `ado:completedAt`(실제 완료일시) · `ado:inspectedAt`(검사 일시).
- 이 온톨로지에는 유효기간(시작 · 종료) property 가 없다. 작업지시의 수량 · 상태는 `ado:hasWorkOrderReferenceAt` 시점의 값으로 읽는다.

## 5. 판정 규칙 표

판정 규칙 표는 모드 B 에서 주장 하나에 판정 범주를 정하는 규칙 목록이다. 위에서부터 처음 맞는 규칙을 적용한다.

- 규칙이 가리키는 T01~T10 은 `references/query-templates.md` 4절의 template 이다.

| rule_id | 대상 claim_type | 조건 | 결과 범주 | 임계값 |
|---|---|---|---|---|
| `R01` | fact · rule | 작업지시 완료 여부 · 완료일시를 다루는 주장이고, T01 에서 `ado:hasWorkOrderStatus` 가 "완료"인데 `ado:completedAt` 행이 없다 | anomaly | - |
| `R02` | fact | 수량 주장이고 T01 수량 사이에 모순이 있다. `ado:hasPlannedQuantity` − `ado:hasProducedQuantity` ≠ `ado:hasUnproducedQuantity`, `ado:hasInspectionPassedQuantity` + `ado:hasInspectionFailedQuantity` > `ado:hasProducedQuantity`, `ado:hasShipmentApprovedQuantity` > `ado:hasInspectionPassedQuantity` 가운데 하나다. 식에 쓰는 값이 모두 있을 때만 본다 | anomaly | `TH01` |
| `R03` | fact · rule | 문서 시점(4절)이 T01 의 `ado:completedAt` 보다 앞서는데 완료를 주장하거나, 수량 · 작업 상태 값이 T01 과 다르고 문서 시점이 `ado:hasWorkOrderReferenceAt` 보다 앞선다 | temporal | - |
| `R04` | fact | KG 값이 있고 문서 value 와 일치한다. 대상은 T01 의 수량 · 작업 상태 · 제품 · 담당자 · 설비 · 생산 로트, T02 · T04 · T05 · T06 · T10 의 식별자, T03 의 `?measured`, T07 의 행 수, T08 의 `?producedTotal` 이다. 수치는 차이가 TH01 이하, 문자열은 식별자 또는 label 정확 일치 | supported | `TH01` |
| `R05` | fact | KG 값이 있고 R04 의 비교가 불일치한다. 예: 문서 생산 수량과 `ado:hasProducedQuantity` 의 차이가 TH01 을 넘는다 | refuted | `TH01` |
| `R06` | rule | 문서가 장치 · 검사항목을 합격으로 적었는데 T03 의 `?result`(`ado:hasInspectionResult`)가 "불합격"이거나 `?withinTolerance` 가 false 다 | refuted | `TH02` |
| `R07` | rule | 문서 판정이 T03 의 `?result` 와 같고, `?withinTolerance` 가 있으면 합격은 true · 불합격은 false 로 판정과 맞는다 | supported | `TH02` |
| `R08` | rule | 적용 BOM 대로 투입했다는 주장이고 T04 에 `?inAppliedBom` 이 false 인 행이 있다. 투입 입고 로트의 `ado:forMaterial` 자재가 `ado:appliesBom` BOM 의 `ado:listsMaterial` 에 없다는 뜻이다 | refuted | - |
| `R09` | rule | 같은 주장이고 T04 의 투입 로트 행이 1건 이상이며 모두 `?inAppliedBom` 이 true 다 | supported | - |
| `R10` | absence | 없음 · 미발생 주장과 반대되는 기록이 있다. 품질 보류는 T09 ASK true(`ado:heldWorkOrder` · `ado:heldProductionLot` · `ado:heldMaterialLot` 가 대상을 가리킴), 재작업은 T06 1행 이상이다 | refuted | - |
| `R11` | trend | T08 의 `?workOrderCount` 가 TH04 이상이고, 대상 작업지시의 `ado:hasProducedQuantity`(T01)와 T08 의 `?producedAvg` 의 차이가 `?producedAvg` 의 TH03 비율을 넘는다 | anomaly | `TH03`, `TH04` |
| `R12` | 전체 | 근거 property 가 어휘 안이지만 대상에 값이 없다. 해당 template 0행, T09 ASK false 를 포함한다. 예: `ado:inspectedAt` · `ado:hasQuantityPerUnit` 값 없음 | not_in_kg | - |

## 6. 임계값

임계값은 판정 규칙 표가 참조하는 수치 목록이다.

| threshold_id | 뜻 | 값 | 단위 · 비교 방향 |
|---|---|---|---|
| `TH01` | 수량 · 수치 일치 허용 오차 | 0 | 문서 단위(대 · 개 · 건 · 측정 단위), 차이가 이하면 일치 |
| `TH02` | 검사 허용 범위. 근거는 검사항목의 `ado:hasTolerance` | 검사항목별 `ado:hasTolerance` 값(예: QC-T01 온도 오차는 0.5) | T03 의 `?deviation`(측정값과 `ado:hasReferenceValue` 차이의 절댓값)이 이하면 범위 안이며 `?withinTolerance` 가 true 다 |
| `TH03` | 이력 대비 생산 수량 차이 비율. 근거 문서 없는 초기값 | 0.3 | 대상 작업지시 생산 수량과 T08 `?producedAvg` 차이의 절댓값 ÷ `?producedAvg`, 초과면 이상치 |
| `TH04` | 이력 비교 최소 작업지시 수. 근거 문서 없는 초기값 | 3 | T08 `?workOrderCount`, 미만이면 R11 을 적용하지 않는다 |

## 7. 범위 밖 안내와 금지 어휘

범위 밖 안내와 금지 어휘는 온톨로지가 다루지 않는 요청에 답하는 문구와, 질의 · 답변에 쓰지 않을 어휘 목록이다.

- 범위 밖 안내 문구: 「제조 ERP 온톨로지는 작업지시 · 생산 로트 · 검사 · 자재 투입 · 품질 보류 · 재작업 기록과 그 대상 제품 · 자재 · 설비 · 공급업체 · 사람만 다룬다. 원가 · 단가 · 판매가 · 재고 · 납기 · 고객 · 주문은 조회 범위 밖이다.」

- 금지 어휘: 아래 둘이다.
  - 원가 · 단가 · 판매가 · 재고 수량 · 납기 · 고객 · 주문을 뜻하는 IRI: TTL 에 해당 class · property 가 없어 쓰면 지어낸 IRI 가 된다. 범위 밖 안내 문구로 답한다.
  - `adm:sourceChunk` · `adm:sourceQuote`: 추출 출처를 적은 annotation 이며 schema card 어휘가 아니다. 질의와 판정 근거로 쓰지 않는다.

근거: SHACL-SPARQL 규칙 표현, Licensing Oracle 의 type · 논리 · 시간 규칙, Kontrast 불일치 4유형, Anthropic legal · finance skill 의 playbook 기준선
