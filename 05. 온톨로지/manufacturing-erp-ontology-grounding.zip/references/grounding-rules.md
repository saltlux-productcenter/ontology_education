# grounding 규칙

이 문서는 온톨로지를 조회해 답하거나 판정할 때 어휘 · 값 · 부재를 실행 결과에 묶어 두는 고정 규칙을 정한다. 대상 온톨로지가 바뀌어도 고치지 않는다.

## Contents

1. hallucination 발생 자리와 차단 수단
2. 질의 전 확정 항목
3. SPARQL 작성 규칙
4. 0건의 해석
5. 추론 설정
6. repair 규칙
7. 되묻기 규칙
8. 금지 사항

## 1. hallucination 발생 자리와 차단 수단

hallucination(근거 없는 생성)은 온톨로지 조회에서 아래 세 자리에서 생기며, 자리마다 차단 수단이 다르다.

| 자리 | 증상 | 차단 수단 |
|---|---|---|
| 어휘 | 없는 class · property IRI 를 지어내 질의한다. 오류 없이 0건이 나온다 | schema card 를 먼저 읽고 확정 어휘 표에 있는 IRI 만 쓴다 |
| 사실 | 조회하지 않은 값을 기억으로 채운다 | 답과 판정의 값은 실행 결과의 행 · triple 에서만 인용한다 |
| 부재 | 기록 0건을 「사실 없음」으로, 조회 실패를 「해당 없음」으로 읽는다 | 0건을 `no_data` · `blocked` · `error` · `not_loaded` 로 구분하고, 부재는 `FILTER NOT EXISTS` 또는 ASK 로 확인한다 |

OWL 은 open-world 가정이라 기록이 없다는 사실만으로 거짓을 추론하지 않는다. LLM 은 「없으면 거짓」으로 읽는 경향이 있으므로, 부재는 SPARQL 로 확인한 「KG 에 기록 없음」으로만 적는다.

## 2. 질의 전 확정 항목

질의 전 확정 항목은 SPARQL 을 쓰기 전에 정해 둘 4항이다. 하나라도 비면 질의가 실행되더라도 다른 질문의 정답이 나온다.

| 항목 | 확정할 내용 | 비었을 때 생기는 일 |
|---|---|---|
| 어휘 | 쓸 class · property · entity 의 실제 IRI | 없는 IRI 로 0건이 나온다 |
| 답 모양 | 값 · 목록 · 참거짓 · 개수 · 집계 · 경로 | 목록을 물었는데 개수로 답한다 |
| 범위 | repository, named graph, 추론 포함 여부 | 다른 저장소나 추론 전 데이터로 답한다 |
| 실행 가능 여부 | 조회 형태, 금지 구문, 행 상한 | 실행 전에 막히거나 결과가 잘린다 |

네 항목은 첫 조회 기록 앞에 본문으로 적는다.

## 3. SPARQL 작성 규칙

SPARQL 작성 규칙은 template 이 없어 조회문을 새로 쓸 때 지킬 사항이다.

- 조회 형태: SELECT · ASK 를 쓴다. triple 자체가 필요할 때만 CONSTRUCT · DESCRIBE 를 쓴다.
- 금지 구문: INSERT · DELETE · LOAD · CLEAR · CREATE · DROP · COPY · MOVE · ADD 같은 UPDATE 계열과 SERVICE 를 쓰지 않는다.
- prefix: 쓰는 prefix 는 전부 PREFIX 로 선언하고 값은 schema card 2절을 그대로 쓴다.
- IRI: 확정 어휘 표 · entity 표의 IRI 만 쓴다.
- 대상 지정: 대상은 label 문자열 비교가 아니라 IRI 로 지정한다. label 은 표시용으로 OPTIONAL 로만 가져온다.
- 언어 태그: label 은 `references/domain-rules.md` 2절의 언어 우선순위에 따라 `lang()` 으로 거른다.
- LIMIT: SELECT 에는 LIMIT 을 붙이고 SKILL.md 예산 절의 행 상한 이하로 둔다.
- 결정성: 목록에는 ORDER BY 를 붙여 실행마다 같은 순서를 받는다.
- 집계: COUNT · SUM · AVG 와 함께 쓰는 비집계 변수는 모두 GROUP BY 에 넣는다.
- 기간: 날짜 비교는 `xsd:date` 로 형을 맞춘다. 예: `FILTER(?d >= "2024-01-01"^^xsd:date)`.
- 부재: `FILTER NOT EXISTS { ... }` 또는 ASK 로 확인한다.
- 선택 속성: 없을 수 있는 속성은 OPTIONAL 로 감싸 행이 사라지지 않게 한다.
- class 계층: 하위 class 의 instance 까지 모으려면 `rdf:type/rdfs:subClassOf*` 경로를 쓴다.

부재 확인 예시는 아래와 같다. 기간 안에 연결 항목이 하나도 없는 대상을 찾는다.

```sparql
PREFIX ex: <https://example.org/onto#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
SELECT ?entity
WHERE {
  ?entity a ex:EntityA .
  FILTER NOT EXISTS {
    ?entity ex:relatedTo ?item .
    ?item ex:validFrom ?d .
    FILTER(?d >= "2024-01-01"^^xsd:date)
  }
}
ORDER BY ?entity
LIMIT 50
```

## 4. 0건의 해석

0건의 해석은 결과가 비었을 때 원인을 4종으로 나누고 원인별 답변 문구를 정하는 규칙이다.

| 경우 | 공통 status | 판별 | 답변 문구 |
|---|---|---|---|
| 어휘 안, 실행 성공, 0행 | `no_data` | 확정 IRI 만 썼고 도구 status 가 성공 계열 | 「온톨로지에 해당 기록이 없다(조회 조건: …). 기록이 없다는 것이 사실이 없다는 뜻은 아니다.」 |
| 어휘 밖 또는 금지 구문 | `blocked` | 확정 표에 없는 IRI, 도구의 차단 warning | 「요청한 항목은 온톨로지 어휘에 없어 조회하지 않았다. 가까운 항목: ….」 |
| 실행 오류 · 접속 오류 | `error` | 오류 원문, 설정 · 인증 warning | 「조회가 실패해 확인하지 못했다(원인: …).」 |
| 미적재 | `not_loaded` | repository · graph 없음 warning | 「대상 저장소 또는 graph 가 적재되지 않아 조회하지 못했다.」 |

- 집계 결과의 개수 0 과 ASK false 도 `no_data` 와 같은 제한을 받는다.
- `no_data` 로 확정하기 전에 IRI 와 경로를 한 번 재확인한다(entity 상세 또는 schema 조회 1회).
- 조건을 하나씩 빼며 여러 번 다시 실행하지 않는다. 대개 같은 결론에 이르고 예산만 쓴다.

## 5. 추론 설정

추론 설정은 저장소가 만든 추론 결과를 조회에 포함할지를 정하는 값이며, 같은 질의라도 이 값에 따라 결과가 달라진다. 기본값은 `references/domain-rules.md` 2절이다.

- 실행마다 추론 포함 여부를 조회 기록과 JSON 의 `queries[].inferred` 에 적는다.
- 도구가 추론 설정을 인자로 받지 않으면 repository 설정값을 적고, 알 수 없으면 「미확인」으로 적는다.
- 상위 class 로 모으기, 역관계, 동치처럼 추론 전후로 답이 갈리는 질문은 어느 설정으로 답했는지 `[범위]` 줄에 밝힌다.
- class 계층은 추론에 기대지 않고 `rdf:type/rdfs:subClassOf*` 경로를 명시하면 설정과 무관한 결과를 얻는다.

## 6. repair 규칙

repair 규칙은 실행 오류가 났을 때 질의를 고쳐 다시 실행하는 방법과 상한이다.

| 원인 | 오류 신호 | 수정 방법 |
|---|---|---|
| 문법 | parse error, 위치 표시 | 표시된 위치의 구문을 고친다 |
| 미정의 prefix | undefined prefix, unknown namespace | schema card 2절 값으로 PREFIX 선언을 더한다 |
| 없는 IRI | 오류 없이 0행 | 확정 어휘 표와 대조하고, 표 밖 IRI 면 어휘 확정으로 돌아간다 |
| timeout | timeout, 시간 초과 | 조건을 좁히거나 LIMIT 을 줄이고, 전량 비교 FILTER(regex 등)를 IRI 지정으로 바꾼다 |

- 수정 상한은 질의 하나당 2회다.
- 같은 질의를 그대로 다시 실행하지 않는다. 고친 부분이 있을 때만 다시 부른다.
- 같은 오류 문구가 두 번 나오면 상한 전이라도 멈춘다. 고친 부분이 원인이 아니라는 뜻이다.
- 접속 · 인증 · 설정 오류는 질의를 고쳐도 통과하지 못하므로 repair 하지 않고 오류 원문을 사용자에게 알린다.

## 7. 되묻기 규칙

되묻기 규칙은 조회로 풀 수 없는 모호함을 사용자에게 확인하는 조건과 내용이다.

| 상황 | 되묻는 내용 |
|---|---|
| entity 후보 2건 이상 | 후보별 label · type · IRI 를 보여 주고 고르게 한다. `references/domain-rules.md` 3절 자동 선택 규칙에 맞으면 묻지 않는다 |
| 어휘 밖 | 가장 가까운 어휘 후보 3건 이하를 보여 주고 바꿔 물을지 확인한다 |
| 기간 · 단위 불명 | 기간 · 단위에 따라 답이 달라지면 묻는다. 달라지지 않으면 기본값을 밝히고 진행한다 |
| 답 모양 불명 | 값 · 목록 · 개수 가운데 무엇을 원하는지 묻는다 |

- 되물을 항목은 한 번에 모아 묻는다.
- 되물은 뒤에는 도구를 부르지 않고 응답을 기다린다.

## 8. 금지 사항

금지 사항은 두 모드의 모든 단계에 적용한다.

- 확정 어휘 표 밖의 IRI 로 질의하지 않는다.
- 실행 결과에 없는 값을 답이나 판정에 쓰지 않는다.
- UPDATE 계열 구문과 SERVICE 를 쓰지 않는다.
- 0건 · 개수 0 · ASK false 를 「사실 없음」으로 쓰지 않는다.
- label 문자열 일치로 대상을 지정하지 않는다.
- 추론 설정을 적지 않고 답하지 않는다.
- 같은 도구에 같은 인자로 다시 부르지 않는다.

근거: text-to-SQL 의 schema grounding · execution grounding, sparq genai-retrieval(schema card, read-only, SERVICE 차단, repair 상한), neo4j-cypher-skill schema guardrail, SPARQL-LLM 검증 loop, Informatica catalog-and-data-discovery 의 anti-hallucination gate, W3C SPARQL 1.1 Query Language, OWL 2 open-world 가정
