> 2/2 분할 · 마지막 파일

## 6. class 관계 (계속)

| source | predicate | target |
|---|---|---|
| ado:WorkOrder | ado:performedOnMachine | ado:Machine |
| ado:WorkOrder | ado:producesLot | ado:ProductionLot |

## 7. 코드값과 enum

> 값 목록 출처: owl:oneOf, skos:ConceptScheme 의 concept, data property 의 distinct 값(distinct 값이 20개 이하이고 같은 값이 반복되는 경우).

| property | 값 목록 |
|---|---|
| ado:hasInspectionResult | "불합격" |
| ado:hasMaterialType | "반제품", "부자재", "부품" |
| ado:hasWorkOrderStatus | "완료", "품질 보류" |

## 8. 자주 쓰는 경로

- 작업지시의 제품 · 담당자 · 설비: ado:WorkOrder → ado:forProduct → ado:Product, ado:WorkOrder → ado:performedBy → ado:Employee, ado:WorkOrder → ado:performedOnMachine → ado:Machine
- 작업지시의 생산 로트와 검사 기록: ado:WorkOrder → ado:producesLot → ado:ProductionLot → ado:hasInspectionRecord → ado:Inspection(역방향 ado:Inspection → ado:forProductionLot → ado:ProductionLot)
- 검사 기록이 속한 작업지시: ado:Inspection → ado:forWorkOrder → ado:WorkOrder
- 장치별 측정값과 판정: ado:InspectionResult → ado:ofInspection → ado:Inspection, ado:InspectionResult → ado:ofDevice → ado:Device, ado:InspectionResult → ado:ofInspectionItem → ado:InspectionItem
- 장치의 소속 생산 로트: ado:Device → ado:inProductionLot → ado:ProductionLot
- 작업지시의 자재 투입 추적: ado:MaterialConsumption → ado:ofWorkOrder → ado:WorkOrder, ado:MaterialConsumption → ado:ofMaterialLot → ado:MaterialLot → ado:forMaterial → ado:Material → ado:suppliedBySupplier → ado:Supplier
- 품질 보류 대상: ado:QualityHold → ado:heldWorkOrder → ado:WorkOrder, ado:QualityHold → ado:heldProductionLot → ado:ProductionLot, ado:QualityHold → ado:heldMaterialLot → ado:MaterialLot
- 장치의 재작업과 재검사: ado:Rework → ado:reworkedDevice → ado:Device, ado:Rework → ado:referencesInitialInspection → ado:Inspection, 재검사 ado:Inspection → ado:referencesRework → ado:Rework
- 적용 BOM 의 구성품: ado:WorkOrder → ado:appliesBom → ado:Bom → ado:listsMaterial → ado:Material
- 적용 사양서의 검사항목: ado:WorkOrder → ado:appliesSpecification → ado:ProductSpecification → ado:definesInspectionItem → ado:InspectionItem

## 9. 어휘 밖으로 처리할 것

- 원가 · 단가 · 판매가: 비용 · 가격을 나타내는 class · property 가 없다.
- 재고 수량 · 창고: 재고 class · property 가 없다. ado:hasReceivedQuantity 는 입고 로트의 입고량이며 재고가 아니다.
- 납기 · 고객 · 주문: 고객 · 주문 class 가 없다. ado:plannedCompletionAt 은 작업지시의 예정 완료일시이며 납기가 아니다.
- 검사자 · 검사 사용 장비: ado:Inspection 설명에만 있고 연결 property 가 없다. ado:performedBy · ado:performedOnMachine 은 작업지시의 담당자 · 설비다.
- 입고일 · 입고 로트의 공급업체: ado:MaterialLot 에 입고일 property 와 공급업체 연결이 없다. ado:suppliedBySupplier 는 자재 품목(ado:Material)의 승인 공급업체다.
- 품질 보류 일시 · 해제 일시: ado:QualityHold 에 일시 property 가 없다.
- 재작업 조치 내용 · 재작업 담당자: ado:Rework 설명에만 있고 property 가 없다.
- 사람의 소속 조직: ado:Employee 와 ado:Department 를 잇는 property 가 없다.
- 자재별 BOM 소요량: ado:hasQuantityPerUnit · ado:hasUnit 의 domain 이 ado:Bom 이라 자재별 값을 나타내지 못한다.
- 펌웨어 버전 · 설비 점검 유효기간: property 가 없다.
- 혼동 주의 ado:Inspection(검사 기록) · ado:InspectionResult(검사 결과): 검사 기록은 생산 로트 단위 검사 1건(검사번호)이고, 측정값 · 판정은 장치 · 검사항목 단위의 검사 결과에 있다.
- 혼동 주의 ado:MaterialLot(자재 입고 로트) · ado:ProductionLot(생산 로트): 자재 입고 로트는 투입한 자재 묶음이고, 생산 로트는 작업지시가 만든 제품 묶음이다.
- 혼동 주의 ado:Material(자재 품목) · ado:MaterialLot(자재 입고 로트): 품목 유형 · 승인 공급업체는 자재 품목에, 상태 · 입고량은 입고 로트에 있다.
- 혼동 주의 ado:referencesInspection · ado:referencesInitialInspection: 앞의 것은 재검사 기록 → 최초 검사 기록, 뒤의 것은 재작업 기록 → 최초 검사 기록이다.
- 혼동 주의 ado:hasWorkOrderStatus · ado:hasHoldStatus · ado:hasMaterialLotStatus: 각각 작업지시 · 품질 보류 · 자재 입고 로트의 상태다.
- 혼동 주의 ado:Device: label 은 「불합격 장치(시리얼)」이지만 설명은 완제품 개별 장치다. instance 라는 사실만으로 불합격으로 보지 않고 ado:hasInspectionResult 로 판정한다.
