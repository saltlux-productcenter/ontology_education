# 최종 출력 형식

이 문서는 모드 A 와 모드 B 의 최종 출력 구성, JSON 필드 규칙, 지표 산식, 출력 전 점검 항목을 정한다. 값을 채운 예시는 `templates/answer-example.md` 에 있다.

## Contents

1. 모드 A 형식
2. 모드 B 형식
3. 공통 필드 규칙
4. 모드 B 지표 산식
5. 출력 전 점검

## 1. 모드 A 형식

모드 A 의 최종 출력은 요약 줄 4개와 JSON 코드 블록 하나다.

```
[답] 질문에 대한 답 한두 문장
[근거] 조회 번호, template_id 또는 SPARQL, 핵심 행
[범위] repository, 추론 포함 여부, 이번 실행 기준
[미확인] 확인하지 못한 항목과 공통 status. 없으면 「없음」
```

- `[답]`: 값은 실행 결과에서만 가져온다. 결과가 잘렸으면 전체 몇 행 가운데 일부인지 밝힌다.
- `[범위]`: 조회 시각 대신 「이번 실행」 기준임을 적는다.
- `[미확인]`: 비워 두지 않는다. 확인하지 못한 항목이 없으면 「없음」으로 적는다.

```json
{"schema_version": "0.1",
 "mode": "A",
 "question": "",
 "vocabulary": [{"term": "", "iri": "", "source": "schema_card"}],
 "entities": [{"mention": "", "iri": "", "match": "exact", "candidates": []}],
 "queries": [{"id": "Q01", "tool": "", "template_id": "", "sparql": "", "args": {},
   "repository": "", "status": "ok", "row_count": 0, "inferred": true, "repair_count": 0}],
 "answer": "",
 "evidence": [{"query_ref": "Q01", "rows": [], "triples": []}],
 "unresolved": [{"item": "", "status": "no_data", "reason": ""}],
 "warnings": []}
```

## 2. 모드 B 형식

모드 B 의 최종 출력은 요약 줄 4개와 JSON 코드 블록 하나다.

```
[판정 분포] 주장 n건: supported n, refuted n, anomaly n, granularity n, temporal n, not_in_kg n, blocked n
[불일치] refuted · anomaly 판정의 claim_id, rule_id, 문서 값과 KG 값
[미확인] not_in_kg 와 unresolved 의 claim_id 와 공통 status. 없으면 「없음」
[검토 필요] hitl_queue 건수와 claim_id. 없으면 「없음」
```

```json
{"schema_version": "0.1",
 "mode": "B",
 "document": {"name": "", "date": ""},
 "subject": {"mention": "", "iri": "", "match": ""},
 "claims": [{"claim_id": "C01", "subject_mention": "", "attribute": "", "value": "", "unit": "",
   "period": {"start": "", "end": ""}, "quote": "", "location": "", "claim_type": "fact"}],
 "queries": [{"id": "Q01", "tool": "", "template_id": "", "sparql": "", "args": {}, "claim_ids": [],
   "repository": "", "status": "ok", "row_count": 0, "inferred": true, "repair_count": 0}],
 "verdicts": [{"claim_id": "C01", "category": "supported", "rule_id": "", "evidence_refs": ["Q01"],
   "explanation": ""}],
 "unresolved": [{"item": "", "status": "error", "reason": ""}],
 "hitl_queue": [{"claim_id": "", "reason": ""}],
 "metrics": {"judged": [0, 0], "evidence_backed": [0, 0], "rule_backed": [0, 0]}}
```

## 3. 공통 필드 규칙

공통 필드 규칙은 두 모드의 JSON 필드마다 채울 값과 형식이다.

| 필드 | 규칙 |
|---|---|
| `schema_version` | "0.1" |
| `mode` | "A" 또는 "B" |
| `question` | 사용자 질문 원문 |
| `vocabulary[]` | 확정 어휘 표. `source` 는 `schema_card` 또는 도구 이름 |
| `entities[]` · `subject` | `match` 는 `identifier`(식별자 직접 지정) · `exact` · `contains` · `iri` · `auto_rule`(자동 선택 규칙) · `user_choice`(되물어 확정) 가운데 하나. `candidates` 는 후보가 2건 이상이었을 때의 후보 IRI 목록 |
| `queries[]` | 부른 도구마다 하나. `id` 는 `Q01` 부터 매기고 `tool` 은 도구 이름이다. template 을 썼으면 `template_id` 와 `args`, 자유 생성이면 `template_id` 를 빈 문자열로 두고 `sparql` 에 실행한 질의 전문을 적는다. schema 조회 · entity 검색은 `args` 에 인자를 적고 `template_id` · `sparql` 을 비운다 |
| `queries[].status` | 공통 status 5종 가운데 하나. 도구 status 원문은 `warnings[]` 에 적는다 |
| `queries[].inferred` | 추론 포함이면 true, 미포함이면 false, 알 수 없으면 null |
| `answer` | `[답]` 줄과 같은 내용 |
| `evidence[]` | 답에 쓴 조회의 행이나 triple 을 도구 결과 그대로 옮긴다. 행이 많으면 답에 쓴 행만 싣는다 |
| `document` | `name` 은 문서 제목 또는 파일 이름, `date` 는 문서 기준 시점. 없으면 빈 문자열 |
| `claims[]` | `references/verification-mode.md` 1절 claim schema 그대로 |
| `verdicts[]` | 주장마다 하나. `category` 는 판정 범주 7종 가운데 하나, `rule_id` 는 규칙 표의 id(없으면 빈 문자열), `explanation` 은 근거 설명 한두 문장 |
| `unresolved[]` | 확인하지 못한 질문 · 주장. `status` 는 공통 status, `reason` 은 한 문장 |
| `hitl_queue[]` | 사람 검토로 보낸 주장과 이유 |
| `warnings[]` | 도구 warning 원문, 추론 설정 미확인, 결과 잘림 같은 주의 사항 |

- 모든 IRI 는 확정 어휘 표 · entity 표의 값을 그대로 쓴다.
- 날짜는 `2024-01-01` 형식이며, 대화에 없는 날짜와 시각은 지어내지 않는다.
- JSON 은 코드 블록 하나에 담고, 코드 블록 밖에 JSON 조각을 두지 않는다.

## 4. 모드 B 지표 산식

모드 B 지표는 판정의 근거 추적 정도를 `[분자, 분모]` 로 나타낸 값이다.

| 지표 | 분자 | 분모 |
|---|---|---|
| `judged` | `verdicts[]` 에 있는 주장 수 | 추출한 주장 수(하위 주장 포함) |
| `evidence_backed` | `evidence_refs` 가 1개 이상인 판정 수 | `verdicts[]` 수 |
| `rule_backed` | `rule_id` 가 있는 판정 수 | `verdicts[]` 수 |

- 분모가 0 이면 값 대신 「산출 불가」로 적는다. 1.0 이나 0 으로 적지 않는다.
- 요약 줄에 비율을 덧붙여도 되지만 JSON 에는 분자와 분모만 적는다.

## 5. 출력 전 점검

출력 전 점검은 최종 출력을 내기 직전에 확인할 6항이다.

1. 답과 판정의 값이 전부 실행 결과에서 왔는가.
2. 질의와 답에 쓴 어휘가 전부 확정 어휘 표에 있는가.
3. 0건 · 개수 0 · ASK false 를 「없음」으로 쓰지 않았는가.
4. 조회마다 추론 옵션을 적었는가.
5. `[미확인]` 줄을 비워 두지 않았는가. 확인하지 못한 항목이 모두 `unresolved` 에 들어 있는가.
6. JSON 이 코드 블록 하나에 담겨 있고 문법이 맞는가.

근거: text-to-SQL 답변 구성(사용 테이블 · 실행 질의 · 결과), Informatica catalog-and-data-discovery(모든 주장에 도구 응답 또는 데이터 부재 인용), Anthropic legal · finance skill 의 근거 표와 검토 gate, FEVEROUS 라벨 체계
