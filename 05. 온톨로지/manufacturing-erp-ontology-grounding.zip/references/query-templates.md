# SPARQL template

이 문서는 반복되는 조회를 검증된 SPARQL template 으로 정의하는 형식과 사용 규칙을 정한다. template 은 인자 자리만 비워 둔 채 한 번 이상 실행해 결과 열을 확인한 조회문이다.

## Contents

1. template 우선 원칙
2. template 항목 형식
3. 인자 표기
4. template 목록
5. template 사용 절차
6. 새 template 등록 제안

## 1. template 우선 원칙

template 우선 원칙은 맞는 template 이 있으면 SPARQL 을 새로 쓰지 않는다는 규칙이다.

- 맞는 template 이 있으면 인자만 바꿔 쓴다. 자유 생성은 맞는 template 이 없을 때만 한다.
- 「맞는다」는 답 모양과 사용 조건이 모두 맞는다는 뜻이다. 조건을 하나 더하려고 template 본문을 고치면 그 질의는 자유 생성으로 기록한다.
- 근거: template 은 어휘 · 경로 · 결과 열이 한 번 확인되었으므로 hallucination 이 생길 자리가 인자로 줄어든다.

## 2. template 항목 형식

template 항목은 아래 7개 필드로 적는다. 목록 표에는 SPARQL 본문을 뺀 6개를 싣고, 본문은 template_id 를 제목으로 한 코드 블록에 싣는다.

| 필드 | 뜻 |
|---|---|
| `template_id` | 식별자. `T01` 부터 매긴다. 조회 기록과 JSON 의 `queries[].template_id` 에 쓴다 |
| 이름 | 무엇을 조회하는지 나타내는 명사구 |
| 답 모양 | 값 · 목록 · 참거짓 · 개수 · 집계 · 경로 가운데 하나 |
| 인자 | 인자마다 이름 · 형 · 필수 여부 |
| SPARQL 본문 | 인자 자리를 3절 표기로 비운 조회문 |
| 기대 결과 열 | SELECT 변수 이름 목록, ASK 면 boolean |
| 사용 조건 | 이 template 을 고를 질문 유형과 쓰지 않을 경우 |

## 3. 인자 표기

인자 표기는 template 본문에서 실행 때 값을 넣을 자리를 나타내는 규칙이다.

- 인자 자리는 `{{소문자_이름}}` 으로 적는다. 대문자 `{{...}}` 는 skill 작성자가 치환하는 placeholder 이고, 소문자 `{{...}}` 는 실행 때 LLM 이 확정 값으로 바꾸는 template 인자다.
- 형은 4종이다. `iri` 는 꺾쇠로 감싼 절대 IRI 또는 선언된 prefix 이름(`ex:EntityA-001`), `date` 는 `2024-01-01` 형식 문자열(본문이 대상 property 의 datatype 에 맞춰 `^^xsd:date` 또는 시각을 붙인 `^^xsd:dateTime` 으로 감싼다), `integer` 는 정수, `literal` 은 따옴표 안에 넣을 문자열이다.
- `iri` 인자에는 확정 어휘 표 · entity 표에 있는 값만 넣는다.
- `literal` 인자는 따옴표와 역슬래시를 escape 한다.

## 4. template 목록

template 목록은 이 온톨로지에서 검증된 template 전부다.

| template_id | 이름 | 답 모양 | 인자(이름 · 형 · 필수) | 기대 결과 열 | 사용 조건 |
|---|---|---|---|---|---|
| `T01` | 작업지시 기본 정보 | 값 | work_order · iri · 필수 | `?property` `?value` `?valueLabel` | 작업지시의 제품 · 담당자 · 설비 · 생산 로트 · 적용 BOM · 상태 · 수량 · 일시. 값이 IRI 면 `?valueLabel` 을 표시한다. 수량 · 상태는 `ado:hasWorkOrderReferenceAt` 시점 값이다 |
| `T02` | 작업지시의 생산 로트와 검사 기록 | 목록 | work_order · iri · 필수 | `?lotId` `?inspection` `?inspectionId` `?inspectedAt` `?initialInspectionId` `?reworkId` | 로트번호 · 검사번호 · 재검사 참조. `?initialInspectionId` 가 있으면 재검사 기록이다 |
| `T03` | 생산 로트의 검사 결과 | 목록 | production_lot · iri · 필수 | `?inspectionId` `?deviceId` `?itemId` `?itemName` `?measured` `?reference` `?tolerance` `?deviation` `?withinTolerance` `?result` | 장치별 측정값 · 판정과 허용 범위 적합. `?deviation` · `?withinTolerance` 는 기준값 · 허용 오차가 있는 검사항목만 채워진다 |
| `T04` | 작업지시의 자재 투입 추적 | 목록 | work_order · iri · 필수 | `?consumptionId` `?lotId` `?lotStatus` `?materialId` `?materialName` `?approvedSupplierName` `?inAppliedBom` | 투입 기록 → 입고 로트 → 자재 → 승인 공급업체와 적용 BOM 포함 여부. 공급업체는 자재 품목의 승인 공급업체이며 입고 로트의 공급처가 아니다 |
| `T05` | 품질 보류 목록 | 목록 | 없음 | `?holdId` `?holdStatus` `?holdReason` `?heldQuantity` `?workOrderId` `?productionLotId` `?materialLotId` | 보류 대상 · 사유 · 상태. 보류 일시 property 는 없다 |
| `T06` | 장치의 재작업 이력 | 목록 | device · iri · 필수 | `?reworkId` `?initialInspectionId` `?reinspectionId` | 장치의 재작업과 근거 검사 · 재검사. 0행은 KG 에 재작업 기록이 없다는 뜻이다 |
| `T07` | 완료일시 기간의 작업지시 목록 | 목록 | start · date · 필수 / end · date · 필수 | `?workOrder` `?workOrderId` `?status` `?completedAt` `?producedQty` | `ado:completedAt` 이 기간 안인 작업지시. 완료일시가 없는 작업지시는 나오지 않는다 |
| `T08` | 제품별 생산 수량 합계 | 집계 | 없음 | `?product` `?productName` `?workOrderCount` `?producedTotal` `?producedAvg` | 제품별 작업지시 수 · 생산 수량 합계 · 평균. `ado:hasProducedQuantity` 가 있는 작업지시만 센다 |
| `T09` | 품질 보류 대상 여부 | 참거짓 | target · iri · 필수 | boolean | 작업지시 · 생산 로트 · 자재 입고 로트를 가리키는 품질 보류가 있는지. false 는 KG 부재이며 사실 부재가 아니다 |
| `T10` | BOM 구성 자재 | 목록 | bom · iri · 필수 | `?bomId` `?bomRevision` `?materialId` `?materialName` `?materialType` `?approvedSupplierName` `?bomQuantityPerUnit` `?bomUnit` | BOM 구성품과 소요량. 소요량 · 단위는 BOM 단위 값이며 자재별 값이 아니다. BOM IRI 는 T01 의 `ado:appliesBom` 행에서 얻는다 |

T01 작업지시 기본 정보

```sparql
PREFIX ado: <http://example.com/ontology/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?property ?value ?valueLabel
WHERE {
  {{work_order}} a ado:WorkOrder ;
                 ?property ?value .
  FILTER(STRSTARTS(STR(?property), "http://example.com/ontology/"))
  OPTIONAL { ?value rdfs:label ?valueLabel . FILTER(lang(?valueLabel) = "ko") }
}
ORDER BY ?property ?value
LIMIT 50
```

T02 작업지시의 생산 로트와 검사 기록

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT DISTINCT ?lotId ?inspection ?inspectionId ?inspectedAt ?initialInspectionId ?reworkId
WHERE {
  {{work_order}} ado:producesLot ?lot .
  ?lot ado:hasProductionLotId ?lotId .
  OPTIONAL {
    ?lot ado:hasInspectionRecord|^ado:forProductionLot ?inspection .
    ?inspection ado:hasInspectionId ?inspectionId .
    OPTIONAL { ?inspection ado:inspectedAt ?inspectedAt . }
    OPTIONAL { ?inspection ado:referencesInspection/ado:hasInspectionId ?initialInspectionId . }
    OPTIONAL { ?inspection ado:referencesRework/ado:hasReworkId ?reworkId . }
  }
}
ORDER BY ?lotId ?inspectionId
LIMIT 100
```

T03 생산 로트의 검사 결과

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT DISTINCT ?inspectionId ?deviceId ?itemId ?itemName ?measured ?reference ?tolerance ?deviation ?withinTolerance ?result
WHERE {
  {{production_lot}} ado:hasInspectionRecord|^ado:forProductionLot ?inspection .
  ?inspection ado:hasInspectionId ?inspectionId .
  ?res ado:ofInspection ?inspection ;
       ado:ofDevice/ado:hasDeviceId ?deviceId ;
       ado:ofInspectionItem ?item .
  ?item ado:hasInspectionItemId ?itemId .
  OPTIONAL { ?item ado:hasInspectionItemName ?itemName . }
  OPTIONAL { ?item ado:hasReferenceValue ?reference . }
  OPTIONAL { ?item ado:hasTolerance ?tolerance . }
  OPTIONAL { ?res ado:hasMeasuredValue ?measured . }
  OPTIONAL { ?res ado:hasInspectionResult ?result . }
  BIND(ABS(?measured - ?reference) AS ?deviation)
  BIND(?deviation <= ?tolerance AS ?withinTolerance)
}
ORDER BY ?inspectionId ?deviceId ?itemId
LIMIT 200
```

T04 작업지시의 자재 투입 추적

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT ?consumptionId ?lotId ?lotStatus ?materialId ?materialName ?approvedSupplierName ?inAppliedBom
WHERE {
  ?mc ado:ofWorkOrder {{work_order}} ;
      ado:hasMaterialConsumptionId ?consumptionId .
  OPTIONAL {
    ?mc ado:ofMaterialLot ?lot .
    ?lot ado:hasMaterialLotId ?lotId ;
         ado:forMaterial ?material .
    ?material ado:hasMaterialId ?materialId .
    OPTIONAL { ?lot ado:hasMaterialLotStatus ?lotStatus . }
    OPTIONAL { ?material ado:hasMaterialName ?materialName . }
    OPTIONAL { ?material ado:suppliedBySupplier/ado:hasSupplierName ?approvedSupplierName . }
    BIND(EXISTS { {{work_order}} ado:appliesBom/ado:listsMaterial ?material } AS ?inAppliedBom)
  }
}
ORDER BY ?consumptionId ?lotId
LIMIT 200
```

T05 품질 보류 목록

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT ?holdId ?holdStatus ?holdReason ?heldQuantity ?workOrderId ?productionLotId ?materialLotId
WHERE {
  ?hold a ado:QualityHold ;
        ado:hasQualityHoldId ?holdId .
  OPTIONAL { ?hold ado:hasHoldStatus ?holdStatus . }
  OPTIONAL { ?hold ado:hasHoldReason ?holdReason . }
  OPTIONAL { ?hold ado:hasHeldQuantity ?heldQuantity . }
  OPTIONAL { ?hold ado:heldWorkOrder/ado:hasWorkOrderId ?workOrderId . }
  OPTIONAL { ?hold ado:heldProductionLot/ado:hasProductionLotId ?productionLotId . }
  OPTIONAL { ?hold ado:heldMaterialLot/ado:hasMaterialLotId ?materialLotId . }
}
ORDER BY ?holdId
LIMIT 100
```

T06 장치의 재작업 이력

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT ?reworkId ?initialInspectionId ?reinspectionId
WHERE {
  ?rework ado:reworkedDevice {{device}} ;
          ado:hasReworkId ?reworkId .
  OPTIONAL { ?rework ado:referencesInitialInspection/ado:hasInspectionId ?initialInspectionId . }
  OPTIONAL {
    ?reinspection ado:referencesRework ?rework ;
                  ado:referencesInspection ?initial ;
                  ado:hasInspectionId ?reinspectionId .
  }
}
ORDER BY ?reworkId ?reinspectionId
LIMIT 50
```

T07 완료일시 기간의 작업지시 목록

```sparql
PREFIX ado: <http://example.com/ontology/>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
SELECT ?workOrder ?workOrderId ?status ?completedAt ?producedQty
WHERE {
  ?workOrder a ado:WorkOrder ;
             ado:completedAt ?completedAt .
  OPTIONAL { ?workOrder ado:hasWorkOrderId ?workOrderId . }
  OPTIONAL { ?workOrder ado:hasWorkOrderStatus ?status . }
  OPTIONAL { ?workOrder ado:hasProducedQuantity ?producedQty . }
  FILTER(?completedAt >= "{{start}}T00:00:00"^^xsd:dateTime && ?completedAt <= "{{end}}T23:59:59"^^xsd:dateTime)
}
ORDER BY ?completedAt ?workOrder
LIMIT 200
```

T08 제품별 생산 수량 합계

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT ?product ?productName (COUNT(DISTINCT ?workOrder) AS ?workOrderCount) (SUM(?qty) AS ?producedTotal) (AVG(?qty) AS ?producedAvg)
WHERE {
  ?workOrder a ado:WorkOrder ;
             ado:forProduct ?product ;
             ado:hasProducedQuantity ?qty .
  OPTIONAL { ?product ado:hasProductName ?productName . }
}
GROUP BY ?product ?productName
ORDER BY ?product
LIMIT 50
```

T09 품질 보류 대상 여부

```sparql
PREFIX ado: <http://example.com/ontology/>
ASK {
  ?hold a ado:QualityHold .
  { ?hold ado:heldWorkOrder {{target}} . }
  UNION { ?hold ado:heldProductionLot {{target}} . }
  UNION { ?hold ado:heldMaterialLot {{target}} . }
}
```

T10 BOM 구성 자재

```sparql
PREFIX ado: <http://example.com/ontology/>
SELECT ?bomId ?bomRevision ?materialId ?materialName ?materialType ?approvedSupplierName ?bomQuantityPerUnit ?bomUnit
WHERE {
  {{bom}} ado:listsMaterial ?material .
  ?material ado:hasMaterialId ?materialId .
  OPTIONAL { ?material ado:hasMaterialName ?materialName . }
  OPTIONAL { ?material ado:hasMaterialType ?materialType . }
  OPTIONAL { ?material ado:suppliedBySupplier/ado:hasSupplierName ?approvedSupplierName . }
  OPTIONAL { {{bom}} ado:hasBomId ?bomId . }
  OPTIONAL { {{bom}} ado:hasBomRevision ?bomRevision . }
  OPTIONAL { {{bom}} ado:hasQuantityPerUnit ?bomQuantityPerUnit . }
  OPTIONAL { {{bom}} ado:hasUnit ?bomUnit . }
}
ORDER BY ?materialId
LIMIT 100
```

## 5. template 사용 절차

template 사용 절차는 template 하나를 골라 실행하고 결과를 확인하는 순서다.

1. template 선택: 질문의 답 모양과 사용 조건으로 고른다. 둘 이상 맞으면 인자가 적은 것을 쓴다.
2. 인자 채우기: 확정 어휘 표 · entity 표의 값으로 채운다. 표에 없는 값이 필요하면 template 을 쓰지 않고 어휘 확정이나 entity 확정으로 돌아간다.
3. LIMIT 확인: 본문의 LIMIT 이 SKILL.md 예산 절의 행 상한보다 크면 줄인다. 이 변경은 자유 생성으로 보지 않는다.
4. 실행과 대조: 실행 결과의 열이 기대 결과 열과 다르면 template 을 잘못 고른 것이므로 결과를 근거로 쓰지 않는다.
5. 기록: 조회 기록에 template_id 와 인자 값을 적는다.

## 6. 새 template 등록 제안

새 template 등록 제안은 자유 생성한 질의를 다음 작성 때 template 으로 올릴 후보로 남기는 형식이다.

- 제안 조건: 자유 생성한 SPARQL 이 공통 status `ok` 로 실행되었고, 사용자가 그 답을 확인한 경우에만 제안한다.
- 제안 위치: 답변 끝에 아래 형식으로 적는다. skill 파일은 고치지 않는다.
- 인자화: 실행한 질의의 확정 IRI 와 값 가운데 질문마다 바뀌는 것만 `{{소문자_이름}}` 인자로 바꾼다.

```
[template 등록 제안]
- 이름:
- 답 모양:
- 인자: 이름 · 형 · 필수
- SPARQL 본문:
- 기대 결과 열:
- 사용 조건:
- 실행 근거: repository, 추론 옵션, row_count
```

template_id 는 작성자가 목록에 올릴 때 부여한다.

근거: Neo4j Aura CypherTemplate, Oracle AIDP verified-queries, sparq genai-retrieval, t2sparql 경로 template, W3C SPARQL 1.1 Query Language
