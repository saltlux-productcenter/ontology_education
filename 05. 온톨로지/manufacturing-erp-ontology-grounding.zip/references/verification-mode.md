# 문서 검증 모드

이 문서는 모드 B 에서 문서의 주장을 추출하고 온톨로지 사실과 대조해 판정하는 규칙을 정한다. 판정 규칙 자체는 `references/domain-rules.md` 5절 규칙 표에 있다.

## Contents

1. claim schema
2. claim_type 정의
3. claim_type 대응표
4. 판정 범주
5. 판정 순서
6. 주장 분해와 집계
7. 시점 처리
8. 부재 주장 처리
9. 판정 기록

## 1. claim schema

claim schema 는 문서에서 뽑은 주장 하나를 적는 필드 구성이다.

| 필드 | 형 | 뜻 | 규칙 |
|---|---|---|---|
| `claim_id` | string | 주장 식별자 | 문서 등장 순서로 `C01` 부터 매긴다. 하위 주장은 `C03-1` 처럼 붙인다 |
| `subject_mention` | string | 문서가 주장의 주체를 부른 표기 | 원문 표기 그대로 |
| `attribute` | string | 주장이 다루는 속성 | 문서 표기. 대응 IRI 는 확정 어휘 표에 적는다 |
| `value` | string | 주장한 값 | 원문 표기. 수치는 단위와 분리한다 |
| `unit` | string | 값의 단위 | 없으면 빈 문자열 |
| `period` | object | 주장이 가리키는 기간 `{start, end}` | 날짜는 `2024-01-01` 형식. 문서에 없으면 7절 규칙 |
| `quote` | string | 주장의 원문 근거 | 문서의 연속 구절 8자 이상을 글자 그대로. 생략 부호로 잇지 않는다 |
| `location` | string | 문서 안 위치 | 쪽 · 절 · 문단 번호 가운데 문서에 있는 것 |
| `claim_type` | string | 주장 유형 | `fact` · `rule` · `trend` · `absence` 가운데 하나 |

## 2. claim_type 정의

claim_type 은 주장을 대조 방법에 따라 나눈 4종이다.

- fact(사실값): 대상의 속성 값이 특정 값이라는 주장. 예: 「EntityA-001 의 속성값은 12 이다」.
- rule(규정 적합): 대상이 규칙이나 기준을 충족한다, 또는 위반한다는 주장. 예: 「EntityA-001 은 기준을 충족한다」.
- trend(이력 대비): 과거 값과 비교한 변화나 수준에 대한 주장. 예: 「직전 기간 대비 증가했다」.
- absence(없음 · 미발생): 어떤 관계나 사건이 없거나 발생하지 않았다는 주장. 예: 「기간 중 연결 항목이 없다」.

## 3. claim_type 대응표

claim_type 대응표는 주장 유형마다 조회 방식, 쓸 template, 비교 방법을 정한 표다.

| claim_type | 조회 방식 | template_id | 비교 방법 |
|---|---|---|---|
| fact | 작업지시 속성 값(수량 · 작업 상태 · 제품 · 담당자 · 설비 · 완료일시 · 기준일시) | `T01` | R01~R05 를 차례로 적용한다. 수치는 단위를 맞춘 뒤 TH01, 문자열은 정확 일치로 비교한다 |
| fact | 로트 · 검사 · 자재 투입 · 품질 보류 · 재작업 · BOM 연결 | `T02`, `T04`, `T05`, `T06`, `T10` | 문서의 식별자(로트번호 · 검사번호 · 입고 로트번호 · 보류 기록번호 · 조치기록번호 · 자재코드)를 결과 행의 식별자와 정확 일치로 대조한다(R04 · R05) |
| fact | 기간 · 제품 단위의 개수와 합계 | `T07`, `T08` | T07 의 row_count, T08 의 `?producedTotal` 을 문서 값과 비교한다(R04 · R05) |
| rule | 검사 판정 적합(측정값 · 기준값 · 허용 오차) | `T03` | R06 · R07. 허용 범위는 TH02 다 |
| rule | 적용 BOM 대비 투입 자재 적합 | `T04` | R08 · R09 |
| trend | 같은 제품 작업지시 평균 대비 생산 수량 | `T01`, `T08` | R11. TH03 · TH04 |
| absence | 품질 보류 부재 | `T09` | ASK true 면 R10, false 면 R12. 8절 규칙을 함께 적용한다 |
| absence | 재작업 이력 부재 | `T06` | 1행 이상이면 R10, 0행이면 R12 |

## 4. 판정 범주

판정 범주는 주장 하나에 붙이는 판정 결과 7종이다. 판정 주체에 LLM 은 없으며, LLM 은 결과를 옮겨 적고 근거를 설명한다.

| 범주 | 뜻 | 판정 주체 | 예시 조건 |
|---|---|---|---|
| `supported` | 주장이 KG 사실과 일치한다 | 제약 검증 도구 또는 규칙 표 | 문서 값 12, KG `ex:hasAttribute` 값 12 |
| `refuted` | 주장과 KG 사실이 직접 충돌한다 | 제약 검증 도구 또는 규칙 표 | 문서 값 12, KG `ex:hasAttribute` 값 3 |
| `anomaly` | 이력 대비 이상치다 | 규칙 표(집계 계산 + 임계값) | 직전 3개 기간 값이 모두 "값1" 인데 이번 값이 "값3" |
| `granularity` | 문서와 KG 의 세부 수준이 달라 직접 대조할 수 없다 | 규칙 표 또는 사람 검토 | 문서는 요약 서술, KG 는 항목별 값 |
| `temporal` | 시점 차이로 대조할 수 없거나 어긋난다 | 규칙 표(시점 조건) | 문서 기준 시점이 KG `ex:validFrom` 보다 앞선다 |
| `not_in_kg` | KG 에 근거가 없어 판정 보류한다 | ASK 결과와 status | 어휘 안이며 ASK false 또는 `no_data` |
| `blocked` | 온톨로지 어휘 밖의 주장이다 | 어휘 확정 단계 | 주장 속성이 schema card 에 없다 |

조회 status 가 `error` 나 `not_loaded` 인 주장은 판정하지 않고 `unresolved` 에 둔다.

## 5. 판정 순서

판정 순서는 주장 하나에 판정 주체를 적용하는 차례다.

1. 제약 검증 도구: `references/tools.md` 2절의 제약 검증 도구가 있으면 규칙 판정을 맡기고, 위반 항목의 shape 를 rule_id 로 옮겨 적는다.
2. 규칙 표: 도구가 없거나 도구가 다루지 않는 규칙은 `references/domain-rules.md` 5절 규칙 표의 조건을 조회 결과에 적용한다. 차이 · 평균 · 기간 비교 같은 계산 값은 SPARQL 집계로 얻은 값만 쓴다.
3. 사람 검토: 어느 규칙에도 맞지 않는 주장은 판정하지 않고 `hitl_queue` 에 넣는다. 세부 수준 차이로 대조할 수 없는 주장은 `granularity` 로 두고 함께 넣는다.

## 6. 주장 분해와 집계

주장 분해는 측정할 수 없는 서술형 주장을 측정 가능한 하위 주장으로 나누는 것이다.

- 서술형 주장(예: 「전반적으로 기준을 충족한다」)은 규칙 표나 template 으로 확인할 수 있는 하위 주장으로 나눈다. 하위 주장은 `C03-1`, `C03-2` 처럼 상위 claim_id 에 번호를 붙인다.
- 하위 주장의 `quote` 는 상위 주장의 `quote` 를 그대로 쓴다.
- 나눌 수 없으면 `granularity` 로 두고 `hitl_queue` 에 넣는다.
- 하위 판정을 상위 판정으로 모으는 규칙은 아래와 같다. 위에서부터 처음 맞는 줄을 적용한다.

1. 하위 판정에 `refuted` 가 하나라도 있으면 상위는 `refuted` 다.
2. `refuted` 가 없고 `anomaly` 가 있으면 상위는 `anomaly` 다.
3. 하위 판정이 모두 `supported` 면 상위는 `supported` 다.
4. 그 밖의 조합은 상위를 `granularity` 로 두고 `hitl_queue` 에 넣는다.

## 7. 시점 처리

시점 처리는 문서가 가리키는 시점과 KG 값의 유효기간을 맞춰 비교하는 규칙이다.

- 문서 시점을 읽는 자리와 KG 유효기간 property 는 문서의 작성일 또는 검사일시(문서 머리 → 본문 표 순서로 찾는다) ↔ `ado:hasWorkOrderReferenceAt`(작업지시 수량 · 상태의 기준일시) · `ado:completedAt`(실제 완료일시) · `ado:inspectedAt`(검사 일시) 다.
- 주장의 `period` 가 비면 문서 시점을 기준 시점으로 쓴다. 문서 시점도 없으면 되묻는다.
- KG 값은 유효기간(예: `ex:validFrom` · `ex:validTo`)이 기준 시점을 포함하는 것만 비교한다.
- 기준 시점에 유효한 KG 값이 없고 다른 시점의 값만 있으면 `temporal` 로 두고, 가장 가까운 시점의 값을 설명에 적는다.
- 기간 비교는 `xsd:date` 로 형을 맞춘 SPARQL 조건으로 한다. LLM 이 날짜를 계산하지 않는다.

## 8. 부재 주장 처리

부재 주장 처리는 absence 주장을 판정할 때 KG 부재와 사실 부재를 구분하는 규칙이다.

- KG 부재는 사실 부재가 아니다. KG 에 기록이 없다는 것만으로 absence 주장을 `supported` 로 판정하지 않는다.
- ASK true, 곧 주장과 반대되는 기록이 있으면 `refuted` 다.
- ASK false 나 `no_data` 면 `not_in_kg` 다. 단, 규칙 표에 그 property 를 빠짐없이 기록하는 대상으로 정한 규칙이 있으면 그 규칙의 결과를 따른다.
- 조회 status 가 `blocked` 면 `blocked`, `error` · `not_loaded` 면 판정하지 않고 `unresolved` 에 둔다.

## 9. 판정 기록

판정 기록은 판정을 받은 round 의 본문에 주장마다 한 줄씩 남기는 기록이다.

```
[판정] C01 | supported | R01 | 근거 Q02 | 문서 12, KG 12
[판정] C03 | not_in_kg | - | 근거 Q04 | ASK false
```

- 형식: claim_id, 범주, rule_id(없으면 `-`), 근거 조회 번호, 비교 요약.
- 최종 JSON 의 `verdicts[]` 는 이 기록을 그대로 옮긴다.

근거: FEVER · FEVEROUS 3값 라벨(SUPPORTS · REFUTES · NEI), Kontrast 불일치 4유형, Licensing Oracle 의 SHACL 판정과 abstain, RefChecker claim-triplet, EHRCon 의 비정형 기록 대 정형 테이블 대조, Anthropic legal · finance skill 의 판정 골격, pySHACL SHACL-SPARQL
